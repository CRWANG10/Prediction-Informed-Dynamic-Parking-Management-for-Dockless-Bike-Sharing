"""Formula / protocol regression checks using only artificial inputs."""
import importlib.util
import unittest
from unittest.mock import patch
import numpy as np
from mobility_algorithms.prediction import metrics, community_metrics, seed_metric_summary, forecast, Split
from mobility_algorithms.prediction.pipeline import TrainingConfig, run_paper_protocol
from mobility_algorithms.geofencing import (Candidate, simulate, inventory_after_turnover, apply_dispatch,
    theoretical_capacities, microgrid_centers, fence_occupancy_metrics, spatial_coverage, allocate)


class ManuscriptPredictionTests(unittest.TestCase):
    def test_paper_parameters(self):
        cfg = TrainingConfig()
        self.assertEqual((cfg.hidden_units, cfg.learning_rate, cfg.batch_size, cfg.dropout, cfg.max_epochs),
                         (320, 0.005, 64, 0.3, 150))
        self.assertIsNone(cfg.patience)  # Unreported, not fabricated.

    def test_equation20_root_before_grid_mean(self):
        result = metrics(np.zeros((24, 2)), np.tile([1, 3], (24, 1)))
        self.assertEqual(result["RMSE"], 2)
        self.assertAlmostEqual(result["RMSE_pooled_diagnostic"], np.sqrt(5))

    def test_equation21_positive_observations_without_epsilon(self):
        result = metrics([[0, 0.5], [2, 0]], [[100, 1], [1, 100]])
        self.assertEqual(result["MAPE"], 75)
        self.assertEqual(result["n_positive_observations"], 2)
        self.assertIsNone(metrics([0, 0], [1, 1])["MAPE"])

    def test_equal_community_average(self):
        result = community_metrics(np.ones((24, 3)), np.tile([1, 1, 4], (24, 1)), [1, 1, 2])
        self.assertEqual(result["equal_community_mean"]["MAE"], 1.5)

    def test_seed_std_and_ensemble_are_different_operations(self):
        truth = np.ones((24, 1))*2
        reports = [community_metrics(truth, np.ones_like(truth)*value, [1]) for value in (1, 2, 3)]
        summary = seed_metric_summary(reports)[0]
        self.assertAlmostEqual(summary["MAE"]["mean"], 2/3)
        self.assertAlmostEqual(summary["MAE"]["sample_std"], np.std([1, 0, 1], ddof=1))
        self.assertEqual(metrics(truth, truth)["MAE"], 0)

    def test_expanding_protocol_keeps_partition_and_seed_order(self):
        calls = []
        labels = np.array([1, 2])
        def fake_forecast(demand, split, supplied_labels, **kwargs):
            calls.append((len(demand), split.train_end, split.validation_end, split.history,
                          kwargs["training"]["seed"], kwargs["k"], supplied_labels.copy()))
            pred = np.zeros((24, 2))
            return {"test": pred, "test_community_metrics": community_metrics(np.ones((24, 2)), pred, supplied_labels)}
        with patch("mobility_algorithms.prediction.pipeline.forecast", side_effect=fake_forecast):
            result = run_paper_protocol(np.ones((168, 2)), labels, training={"patience": 6})
        self.assertEqual(len(calls), 9)
        self.assertEqual([call[4] for call in calls], [42, 123, 2024]*3)
        self.assertEqual([call[:4] for call in calls[::3]], [(120, 72, 96, 24), (144, 96, 120, 24), (168, 120, 144, 24)])
        for call in calls:
            self.assertEqual(call[5], 7)
            np.testing.assert_array_equal(call[6], labels)
        self.assertEqual(result["partition_training_hours"], 72)

    def test_protocol_rejects_unspecified_patience_and_nonpaper_tuning(self):
        with self.assertRaises(ValueError):
            run_paper_protocol(np.ones((168, 2)), [1, 1])
        with self.assertRaises(ValueError):
            run_paper_protocol(np.ones((168, 2)), [1, 1], training={"patience": 5, "hidden_units": 8})

    @unittest.skipUnless(importlib.util.find_spec("torch"), "optional torch is not installed")
    def test_global_candidates_keep_community_models(self):
        demand = np.tile(np.arange(1, 41)[:, None], (1, 4)).astype(float)
        args = dict(split=Split(24, 32, 6), labels=[1, 1, 2, 2], k=3,
                    training={"max_epochs": 1, "hidden_units": 4, "patience": 1})
        community = forecast(demand, neighbor_scope="community", **args)
        global_run = forecast(demand, neighbor_scope="global", **args)
        self.assertEqual(len(community["communities"]), 2)
        self.assertEqual(len(global_run["communities"]), 2)
        local_ids = community["communities"][0]["neighbor_ids_global"]
        global_ids = global_run["communities"][0]["neighbor_ids_global"]
        self.assertTrue((local_ids < 2).all())
        self.assertTrue((global_ids >= 2).any())

    @unittest.skipUnless(importlib.util.find_spec("torch"), "optional torch is not installed")
    def test_equation17_no_grid_embedding_in_output_head(self):
        from mobility_algorithms.prediction.models import IrConvLSTMRegressor
        model = IrConvLSTMRegressor(9, 320, .3, 2)
        self.assertFalse(hasattr(model, "grid_embedding"))
        self.assertEqual(model.head[-1].in_features, 320)


class ManuscriptFenceTests(unittest.TestCase):
    def test_microgrid_geometry_and_equation22(self):
        centers = microgrid_centers([[0, 0]])
        self.assertEqual(centers.shape, (1, 100, 2))
        np.testing.assert_array_equal(centers[0, 0], [-225, -225])
        np.testing.assert_allclose(theoretical_capacities([2500, 2500], [.8, 1]), [250, 0])

    def test_night_boundary_and_turnover(self):
        for hour in (0, 5):
            np.testing.assert_array_equal(inventory_after_turnover([4, 2], [1, 3], hour), [5, 5])
        for hour in (6, 23):
            np.testing.assert_array_equal(inventory_after_turnover([4, 2], [1, 3], hour), [1, 3])

    def test_dispatch_feedback_and_conservation(self):
        result = simulate([0, 0], [[1, 3], [0, 0]], [[5, 0], [0, 0]],
                          [Candidate("a", 0, 1), Candidate("b", 1, 3)], [[0, 0], [1000, 0]],
                          adjacency={}, start_hour=0, turnover_dispatch_order="turnover_then_dispatch")
        first, second = result["hourly"]
        np.testing.assert_array_equal(first["next_inventory"], [2, 3])
        np.testing.assert_array_equal(second["start_inventory"], [2, 3])
        self.assertEqual(first["next_inventory"].sum(), 5)
        self.assertAlmostEqual(first["dispatch_cost_CNY"], 3*4.1)

    def test_daytime_relocation_does_not_create_inventory(self):
        result = simulate([10, 0], [[0, 4]], [[0, 0]], [Candidate("a", 0, 1), Candidate("b", 1, 4)],
                          [[0, 0], [1000, 0]], adjacency={}, start_hour=6,
                          turnover_dispatch_order="turnover_then_dispatch")
        self.assertEqual(result["hourly"][0]["next_inventory"].sum(), 0)
        self.assertEqual(result["hourly"][0]["dispatch"]["relocated_bicycles"], 0)

    def test_occupancy_share_not_capacity_utilization(self):
        allocation = allocate([11], [Candidate("a", 0, 10), Candidate("b", 0, 10)])
        result = fence_occupancy_metrics(allocation, {"a": 1, "b": 0})
        self.assertEqual(result["occupied_fence_share"], .5)
        self.assertEqual(result["empty_fence_share"], .5)
        self.assertEqual(result["fences"][0]["occupancy_rate"], .1)

    def test_coverage_100m_boundary(self):
        result = spatial_coverage([[100, 0], [100.001, 0]], [[0, 0]])
        np.testing.assert_array_equal(result["covered"], [True, False])

    def test_static_layout_is_fixed(self):
        result = simulate([0], [[1], [5]], [[2], [4]], [Candidate("a", 0, 2), Candidate("b", 0, 3)],
                          [[0, 0]], static_required=[1], adjacency={},
                          turnover_dispatch_order="turnover_then_dispatch")
        static = [row for row in result["hourly"] if row["strategy"] == "historical_static"]
        self.assertEqual(static[0]["allocation"]["assignments"], static[1]["allocation"]["assignments"])
        self.assertEqual(static[1]["activations_after_setup"], 0)
        self.assertIsNone(result["summary"][0]["mean_occupied_fence_share"])

    def test_unspecified_spatial_or_event_order_is_not_invented(self):
        with self.assertRaises(ValueError):
            simulate([0], [[1]], [[1]], [], [[0, 0]])
        with self.assertRaises(ValueError):
            apply_dispatch([1, 0], [{"source_grid_id": 0, "target_grid_id": 1, "bicycles": 2}])
