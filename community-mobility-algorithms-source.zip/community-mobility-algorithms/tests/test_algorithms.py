import importlib.util
import tempfile
import unittest
from pathlib import Path
import numpy as np
from mobility_algorithms.community import detect_communities, aggregate_arrivals, grid_indices
from mobility_algorithms.prediction import Split, make_features, semantic_neighbors, metrics, forecast
from mobility_algorithms.geofencing import (Candidate, allocate, build_adjacency, empirical_capacities,
    land_capacities, required_capacity, evaluate_allocation, greedy_dispatch,
    rank_candidates, match_static_capacity, simulate)
from mobility_algorithms._io import write_json


class CommunityTests(unittest.TestCase):
    def test_partition_and_duplicate_edges(self):
        edges = [(0, 1, 10), (0, 1, 10), (1, 0, 20), (2, 3, 20), (3, 2, 20)]
        result = detect_communities(5, edges)
        self.assertEqual(result["labels"][0], result["labels"][1])
        self.assertEqual(result["labels"][2], result["labels"][3])
        self.assertNotEqual(result["labels"][0], result["labels"][2])
        dedup = detect_communities(5, [(0, 1, 20), *edges[2:]])
        np.testing.assert_array_equal(result["labels"], dedup["labels"])
        self.assertAlmostEqual(result["modularity"], dedup["modularity"])

    def test_empty_graph_and_filter(self):
        result = detect_communities(1, [])
        self.assertEqual(result["modularity"], 0)
        self.assertEqual(result["labels"].tolist(), [1])
        result = detect_communities(2, [], min_size=2)
        self.assertEqual(result["labels"].tolist(), [-1, -1])

    def test_invalid_edge(self):
        for edge in [(0, 2, 1), (0, 1, -1), (0.5, 1, 2), (0, 1, float("nan"))]:
            with self.assertRaises(ValueError):
                detect_communities(2, [edge])

    def test_grid_boundary_and_arrival_totals(self):
        cells = grid_indices([[-0.1, 0], [0, 0], [500, 500]])
        np.testing.assert_array_equal(cells, [[-1, 0], [0, 0], [1, 1]])
        counts = aggregate_arrivals([0, 0, 2], [1, 1, 0], 3, 2)
        self.assertEqual(counts.sum(), 3)
        self.assertEqual(counts[0, 1], 2)
        self.assertEqual(aggregate_arrivals([], [], 3, 2).sum(), 0)


class FeatureTests(unittest.TestCase):
    def setUp(self):
        self.demand = np.arange(40*3).reshape(40, 3).astype(float)
        self.split = Split(24, 32, 6)

    def test_training_statistics_do_not_use_future(self):
        changed = self.demand.copy()
        changed[24:] = 100000
        a = make_features(self.demand, self.split, "lstm")
        b = make_features(changed, self.split, "lstm")
        np.testing.assert_array_equal(a["normalization"][0], b["normalization"][0])
        np.testing.assert_array_equal(a["train"][0], b["train"][0])
        expected = (self.demand[:6, 0]-self.demand[:24, 0].mean())/self.demand[:24, 0].std()
        np.testing.assert_allclose(a["train"][0][0, :, 0], expected)

    def test_current_target_not_in_window(self):
        original = make_features(self.demand, self.split, "lstm")
        changed = self.demand.copy()
        changed[32] = 99999
        mutated = make_features(changed, self.split, "lstm")
        np.testing.assert_array_equal(original["test"][0][:3], mutated["test"][0][:3])

    def test_neighbors_are_community_limited(self):
        ids, weights = semantic_neighbors(self.demand[:24], 4, labels=[0, 0, 1])
        self.assertEqual(ids[0, 0], 1)
        np.testing.assert_array_equal(ids[2], [-1]*4)
        np.testing.assert_allclose(weights.sum(axis=1), [1, 1, 0])

    def test_constant_and_single_grid(self):
        ids, weights = semantic_neighbors(np.ones((10, 2)), 3)
        np.testing.assert_allclose(weights.sum(axis=1), 1)
        ids, weights = semantic_neighbors(np.ones((10, 1)), 2)
        self.assertTrue((ids == -1).all())
        self.assertEqual(weights.sum(), 0)

    def test_individual_neighbor_channels(self):
        ids, weights = semantic_neighbors(self.demand[:24], 2)
        features = make_features(self.demand, self.split, "irconv", neighbor_ids=ids, neighbor_weights=weights)
        x = features["train"][0]
        self.assertEqual(x.shape, (18*3, 6, 4))
        np.testing.assert_allclose(x[:, :, 1], x[:, :, 2:].sum(axis=2), atol=1e-6)

    def test_bad_splits_and_shapes(self):
        for split in [Split(6, 12, 6), Split(24, 24, 6), Split(24, 40, 6)]:
            with self.assertRaises(ValueError):
                make_features(self.demand, split, "lstm")
        with self.assertRaises(ValueError):
            forecast(self.demand, self.split, labels=[1, -1, 1], model="naive")
        with self.assertRaises(ValueError):
            make_features(self.demand, self.split, "conv", lattice=[[0, 0]]*3)

    def test_metrics_zero_and_fractional_targets(self):
        result = metrics([0, 1, 2], [-1, 2, 1])
        self.assertAlmostEqual(result["MAE"], 2/3)
        self.assertAlmostEqual(result["MAPE"], 75)
        self.assertAlmostEqual(result["MAPE_nonzero"], 75)
        self.assertIsNone(metrics([0, 0], [0, 1])["MAPE_nonzero"])
        self.assertAlmostEqual(metrics([0.5], [0])["MAE"], 0.5)
        with self.assertRaises(ValueError):
            metrics([1], [[1]])

    def test_naive_rolling_alignment(self):
        result = forecast(self.demand, self.split, labels=[1, 2, 1], model="naive")
        np.testing.assert_array_equal(result["test"], self.demand[31:39])


class FenceTests(unittest.TestCase):
    def test_unique_reservation_and_capacity_conservation(self):
        candidates = [Candidate("a", 0, 3), Candidate("b", 1, 5)]
        result = allocate([8, 8], candidates, {0: [1], 1: [0]})
        self.assertEqual(len({a["fence_id"] for a in result["assignments"]}), 2)
        self.assertEqual(result["capacity"].sum(), 8)
        np.testing.assert_array_equal(result["local_capacity"]+result["adjacent_capacity"], result["capacity"])

    def test_zero_requirement_and_no_candidates(self):
        self.assertEqual(allocate([0], [Candidate("a", 0, 2)])["assignments"], [])
        result = allocate([2], [])
        self.assertEqual(result["unmet_requirement"][0], 2)

    def test_invalid_candidates_and_adjacency(self):
        with self.assertRaises(ValueError):
            allocate([1], [Candidate("a", 0, 1), Candidate("a", 0, 2)])
        with self.assertRaises(ValueError):
            allocate([1], [Candidate("a", 0, 1.2)])
        with self.assertRaises(ValueError):
            allocate([1], [], {0: [0]})

    def test_priorities_and_capacity_definitions(self):
        candidates = rank_candidates([Candidate("a", 0, 1, 10, 0), Candidate("b", 0, 1, 0, 10)], 1)
        self.assertAlmostEqual(candidates[0].priority, 0.5)
        self.assertAlmostEqual(candidates[1].priority, 0.5)
        np.testing.assert_array_equal(empirical_capacities([[0, 2], [0, 4]], 1), [1, 4])
        np.testing.assert_array_equal(land_capacities([0, 5], 2), [0, 2])
        np.testing.assert_array_equal(required_capacity([1, 3], [2, 1], [5, 0]), [0, 4])

    def test_evaluation_conservation(self):
        result = allocate([2, 0], [Candidate("a", 0, 3)])
        evaluation = evaluate_allocation(result, [5, 1])
        np.testing.assert_array_equal(evaluation["accommodated"]+evaluation["overflow"], [5, 1])
        self.assertAlmostEqual(evaluation["accommodation_rate"], 0.5)

    def test_dispatch_conservation(self):
        result = greedy_dispatch([5, 0, 0], [0, 2, 1], [[0, 0], [100, 0], [300, 0]])
        self.assertEqual(result["relocated_bicycles"], 3)
        self.assertEqual(result["remaining_overflow"].sum(), 2)
        self.assertEqual(result["remaining_spare"].sum(), 0)
        self.assertAlmostEqual(result["bike_km"], 0.5)

    def test_matched_capacity_reports_discrete_gap(self):
        result = match_static_capacity([2], 5, [Candidate("a", 0, 3), Candidate("b", 0, 3)])
        self.assertEqual(result["matched_capacity"], 3)
        self.assertEqual(result["capacity_gap"], 2)

    def test_future_actuals_cannot_change_decision(self):
        inputs = dict(initial_inventory=[1, 1], predicted_arrivals=[[1, 2]],
                      candidates=[Candidate("a", 0, 3), Candidate("b", 1, 4)], centers_m=[[0, 0], [500, 0]],
                      radius_m=750, turnover_dispatch_order="turnover_then_dispatch")
        first = simulate(actual_arrivals=[[1, 2]], **inputs)
        second = simulate(actual_arrivals=[[100, 200]], **inputs)
        self.assertEqual(first["hourly"][0]["allocation"]["assignments"], second["hourly"][0]["allocation"]["assignments"])

    def test_adjacency_radius(self):
        self.assertEqual(build_adjacency([[0, 0], [750, 0], [1501, 0]], 750), {0: [1], 1: [0], 2: []})


class IntegrationTests(unittest.TestCase):
    def test_release_allowlist_and_sensitive_content_checks(self):
        from scripts.build_release import ROOT, FILES, approved_files, checksum_manifest
        payload = approved_files()
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for name in FILES:
                path = root/name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(payload[name])
            (root/"SHA256SUMS.txt").write_text(checksum_manifest(payload), encoding="utf-8")
            self.assertEqual(set(approved_files(root)), set(FILES))
            # An accidental data file outside ignored runtime directories blocks release.
            extra = root/"accidental.json"
            extra.write_text("{}", encoding="utf-8")
            with self.assertRaises(ValueError):
                approved_files(root)
            extra.unlink()
            (root/"SHA256SUMS.txt").unlink()
            # Assemble an artificial credential; no actual token is used.
            (root/"README.md").write_text("gh"+"p_"+"a"*36, encoding="utf-8")
            with self.assertRaises(ValueError):
                approved_files(root)

    def test_synthetic_pipeline(self):
        from examples.synthetic_demo import run_demo
        self.assertTrue(run_demo()["synthetic_only"])

    def test_output_does_not_overwrite(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/"result.json"
            write_json(path, {"synthetic": True})
            with self.assertRaises(FileExistsError):
                write_json(path, {"synthetic": False})

    @unittest.skipUnless(importlib.util.find_spec("torch"), "optional torch is not installed")
    def test_all_neural_models_one_epoch(self):
        from examples.synthetic_demo import run_demo
        for model in ("lstm", "conv", "irconv"):
            with self.subTest(model=model):
                result = run_demo(model, 1)
                self.assertTrue(np.isfinite(result["test_MAE"]))

    @unittest.skipUnless(importlib.util.find_spec("statsmodels"), "optional statsmodels is not installed")
    def test_arima_rolling_future_invariance(self):
        from mobility_algorithms.prediction.arima import rolling_arima
        demand = (2+np.sin(np.arange(30))).reshape(-1, 1)
        split = Split(18, 24, 6)
        original = rolling_arima(demand, split, orders=[(1, 0, 0)])
        demand[24:] = 999
        changed = rolling_arima(demand, split, orders=[(1, 0, 0)])
        np.testing.assert_array_equal(original["validation"], changed["validation"])
        np.testing.assert_array_equal(original["test"][0], changed["test"][0])


if __name__ == "__main__":
    unittest.main()

