# 社区识别、停车需求预测与电子围栏算法

[English](README.en.md)

依据修订稿第 3 节与第 5 节核对的 Python 算法仓库，将**社区识别、需求预测、电子围栏**拆分为三个独立模块。既可单独使用，也可通过数组接口连接成完整流程。

本仓库只提供算法、说明和**运行时生成的纯合成示例**，不附带真实出行数据、研究区域坐标、车辆标识、原始表格、模型权重或论文实验结果。示例数值不代表任何真实城市或论文结论。

## 1. 论文参数与核对范围

| 项目 | 采用设置 / 计算口径 | 依据 |
| --- | --- | --- |
| 网格 / 微网格 | 500 m / 50 m，每格 10×10 个候选微网格 | §3.1.1、§3.3.1 |
| 时间分辨率 / 输入历史 | 1 小时 / 24 小时 | §3.2.1、§5.2 |
| 语义邻居 | K=7；同社区/全局只改变候选池，模型仍逐社区训练 | §3.2.2、§5.2 |
| 神经网络 | 320 hidden units，Adam，lr=0.005，MSE，batch=64，dropout=0.3，最多 150 epochs | §5.2 |
| 神经网络随机种子 | 42、123、2024；指标逐种子计算后求均值和样本标准差 | §5.2 |
| 社区 RMSE | 每个网格先计算 24 小时 RMSE，再对社区内网格等权平均 | 式(20) |
| MAPE | 仅真实需求 >0 的观测，无 epsilon | 式(21) |
| 理论围栏容量 | 面积×(1−不适宜比例)/2 m² | 式(22) |
| 历史活动权重 | 起点 0.5，终点 0.5 | 式(24) |
| 空间覆盖 / 调度成本 | 100 m / 4.1 CNY·车⁻¹·km⁻¹ | §5.3、式(30) |
| 深夜时段 | 0:00≤小时<6:00 累积；6:00 起日间周转 | 作者本次补充确认 |

本文未报告早停 patience、相邻候选范围及小时内“周转/调度”的确切先后顺序。代码将前两者保留为显式参数，对第三项要求显式选择当前支持的时序，详见 [算法与逐项核对说明](docs/ALGORITHMS.md)。已报告设置已对齐；这些未报告细节不能宣称已由论文验证。

### 模块与算法

| 模块 | 主要内容 | 独立输入 | 主要输出 |
| --- | --- | --- | --- |
| `community` | 有向加权 OD 网络、Louvain、可选小社区过滤 | 训练期聚合 OD 边 | 社区标签、模块度、保留掩码 |
| `prediction` | 同社区 Pearson 语义邻居、IrConv+LSTM、LSTM、空间 CNN+LSTM、ARIMA、持久性基线 | 时间×网格需求矩阵、时间切分、可选社区标签 | 验证/测试预测、误差指标 |
| `geofencing` | 土地容量、等权 OD 排序、局部及相邻分配、固定静态对照、容量匹配、反馈调度 | 库存、预测到达量、候选围栏及容量 | 激活方案、溢出量、调度距离与成本 |

预测模块不调用社区识别，电子围栏模块不调用预测。可以使用自己的社区标签，或把其他模型的输出接入电子围栏。

```text
mobility_algorithms/
  community/       社区识别与网格聚合
  prediction/      特征构建、模型、训练、评估
  geofencing/      围栏容量与独立分配算法
examples/          纯合成示例生成代码，没有附带数据文件
tests/             算法不变量、时间泄漏及运行测试
scripts/           仅打包明确许可文件的发布工具
docs/              算法定义、隐私与发布说明
```

## 2. 安装

建议 Python 3.10–3.12。在仓库根目录执行：

```bash
python -m venv .venv
```

Windows PowerShell 激活：`.venv\Scripts\Activate.ps1`；Linux/macOS 激活：`source .venv/bin/activate`。

安装基础模块（NumPy、NetworkX；支持社区、围栏和持久性预测）：

```bash
python -m pip install -e .
```

安装全部预测依赖（额外包括 PyTorch、statsmodels）：

```bash
python -m pip install -e ".[prediction]"
```

神经网络训练默认使用 CPU。模块导入不训练、不扫描本地目录、不连接网络。安装依赖由 pip 完成。

## 3. 零数据快速演示

在仓库根目录运行：

```bash
python -m examples.synthetic_demo
python -m examples.synthetic_demo --model irconv --epochs 2
```

第一条使用持久性预测，无需安装 PyTorch。第二条使用按社区训练的 IrConv+LSTM。两者均串联社区识别、预测和电子围栏，默认只在内存中生成合成数据并打印合成结果，不保存数据。快速示例显式使用更小的网络、短历史和少量训练轮数，仅验证可运行性；其 K=2、hidden=8、history=12、半径 750 m 等均不是论文配置。`naive` 仅为软件演示，未作为论文比较结果。

其他模型参数：`lstm`、`conv`、`arima`。`conv` 是每个时刻进行 3×3 空间卷积再送入普通 LSTM，**不是卷积门控的 ConvLSTM 单元**；名称沿用研究代码的比较模型。文稿没有提供该比较模型的全部内部结构，详见算法说明中的实现边界。

## 4. 三个模块独立运行

先显式生成合成输入（可选；不属于发布包内容）：

```bash
python -m examples.synthetic_demo --write-inputs outputs/synthetic
```

分别运行三个命令，彼此不触发其他模块：

```bash
python -m mobility_algorithms.community --input outputs/synthetic/community_input.json --output outputs/community_result.json
python -m mobility_algorithms.prediction --input outputs/synthetic/prediction_input.json --output outputs/prediction_result.json
python -m mobility_algorithms.geofencing --input outputs/synthetic/geofencing_input.json --output outputs/fence_result.json
```

输入、输出路径必须由使用者指定。为避免覆盖输入或已有结果，输出文件已存在时会报错；重新运行时使用新的输出文件名。`outputs/` 下文件均被 Git 忽略，发布脚本不会收录。

三个输入 JSON 是独立任务示例。需要更换模型并串联时，使用上面的 `synthetic_demo --model ...`，或在自己的调用代码中把预测结果的 `test` 数组传给围栏模块的 `predicted_arrivals`。

## 5. 数据接口

数组的网格顺序必须一致。网格下标使用 `0..N-1`，社区标签为非负整数。没有自动按真实节点 ID 合并或补齐的行为。

### 社区识别

```python
from mobility_algorithms.community import detect_communities

result = detect_communities(
    n_grids=4,
    edges=[(0, 1, 10), (1, 0, 10), (2, 3, 8), (3, 2, 8)],
    resolution=1.0, seed=42, min_size=1,
)
labels = result["labels"]
```

上例是手工合成图。`edges` 是 `(起点下标, 终点下标, 非负流量)`，论文协议要求只由最初 3 天（72 小时）的训练期数据构建，并在后续三个日场景中固定不变。重复边权相加，保留自环，孤立节点也保留。`min_size` 默认不删除社区；小社区标签置为 `-1`，调用者需用 `retained` 掩码同步筛选需求矩阵、坐标和其他网格输入。`modularity` 对应**过滤前**完整划分；零流量图约定返回 0。

可选工具 `grid_indices(points_m, cell_size_m, origin_m)` 要求已投影的米制坐标和固定网格原点；`aggregate_arrivals(time_indices, grid_ids, n_steps, n_grids)` 将匿名网格下标聚合为需求矩阵。不读取原始轨迹，也不推断城市或坐标系。

### 需求预测

`prediction` 的 JSON 顶层字段（同名 Python 参数）：

| 字段 | 类型/含义 |
| --- | --- |
| `demand` | `T×N`，有限非负到达量，时间轴应为等间隔；缺失与真实零值需在上游区分 |
| `split` | `{"train_end":48,"validation_end":60,"history":12}` 为纯合成示例；边界是排他的整数下标 |
| `labels` | 长度 N 的社区标签；省略则所有网格为一组 |
| `model` | `irconv`（默认）、`lstm`、`conv`、`arima`、`naive` |
| `k` | 默认 7，不足时补零；同社区模式不跨社区补齐 |
| `neighbor_scope` | `community`（默认）或 `global`；两种模式必须保留相同 `labels`，不能把全局候选池改成一个全局模型 |
| `lattice` | 仅 `conv` 必需：`N×2` 唯一整数格网坐标 |
| `training` | 可选：`hidden_units`、`learning_rate`、`dropout`、`batch_size`、`loss`、`max_epochs`、`patience`、`seed` |

```python
from mobility_algorithms.prediction import forecast, Split

# demand、labels 由调用者提供，不会自动寻找或加载数据。
# result = forecast(demand, Split(train_end=120, validation_end=144, history=24),
#                   labels=labels, model="irconv", k=7,
#                   training={"seed":42, "patience": chosen_patience})
# arrivals_for_fencing = result["test"]
```

时间边界必须满足 `history < train_end < validation_end < T`。标准化和相关系数只在训练集计算；每个社区独立训练，验证集用于早停。测试采用**滚动一步预测**：预测 t 只看 t 之前已经观测到的历史，并非一次性预测整个未来测试区间。计算原单位的逐网格 MSE 用于验证；输入标准化不改变式(18)损失中的网格权重。

默认参数使用上表中的论文设置。普通 `forecast` 是单次运行；多种子、多日期评价使用以下协议入口。文稿未给出早停耐心值，普通接口的 `patience=None` 运行至最大轮数并选取最佳验证权重；论文协议要求调用者显式提供 `patience`，不会凭空指定“论文值”。随机种子不保证跨硬件逐位一致。

### 三天、多种子论文协议

`run_paper_protocol(demand, labels, model="irconv", training={"patience": chosen_patience}, neighbor_scope="community")` 要求 168×N 的完整七天小时需求矩阵。它执行：

| 场景 | 训练时段 | 验证时段 | 评价时段 |
| --- | --- | --- | --- |
| 第 5 天 | [0,72) | [72,96) | [96,120) |
| 第 6 天 | [0,96) | [96,120) | [120,144) |
| 第 7 天 | [0,120) | [120,144) | [144,168) |

三个场景使用同一组由最初 72 小时 OD 得到的社区标签，不重新识别社区。真实数据识别出多少社区取决于输入；不把论文中的八个社区硬编码为算法目标。

- 神经模型按种子 42、123、2024 分别运行；先计算各社区的日 MAE、RMSE、MAPE，再取种子均值和 `ddof=1` 的样本标准差。
- 仅提供给围栏的 `allocation_predictions` 对种子预测求均值，不能用其误差替代论文表格的种子指标均值。
- ARIMA 对每个网格单独拟合，按训练 AIC 在论文给出的五种阶数组合中选择，不计算种子标准差。
- 对全局邻居比较，保持全部其他参数与社区标签一致，只改 `neighbor_scope="global"`。

命令行加 `--paper-protocol` 可使用上述入口。此时输入 JSON 使用 `demand`、`labels`、可选 `model`、`lattice`、`neighbor_scope` 和含显式 `patience` 的 `training`，不传普通接口的 `split` 或 `k`。评价真实数据应在本地运行；本仓库不含该数据。

### 电子围栏

`geofencing` 的 JSON 顶层字段（同 `simulate` 参数）：

| 字段 | 类型/含义 |
| --- | --- |
| `initial_inventory` | 长度 N 的初始库存；后续库存由周转和调度递推，不再逐小时重置为外部快照 |
| `predicted_arrivals` | `H×N`，预测到达量；可来自任意预测器 |
| `actual_arrivals` | `H×N`，当前小时仅用于事后评价和库存更新；更新结果进入下一小时，不能影响当前激活决策 |
| `candidates` | 列表，每项含 `fence_id`、`grid_id`、正整数 `capacity`；可选训练期 `origin_activity`、`destination_activity` |
| `centers_m` | `N×2`，米制网格中心；不能直接填写经纬度 |
| `static_required` | 可选长度 N 的静态需求；由训练期压力分位数构建 |
| `adjacency` / `radius_m` | 必须显式提供一个；文稿未报告扩展半径，100 m 覆盖半径不可替代扩展范围 |
| `cost_per_bike_km` | 默认 4.1 CNY/车公里 |
| `start_hour` / `night_hours` | 默认从 0 点开始，深夜为 `[0,1,2,3,4,5]` |
| `turnover_dispatch_order` | 必须显式指定 `"turnover_then_dispatch"`；这是本文未详述的实现时序选择，见下文 |
| `observed_fence_occupancy` | 可选 H 个字典：围栏 ID→实际停放数；无真实围栏级观测则占用围栏比例返回空值，不由容量利用率代替 |
| `include_matched_static` | 默认 false；true 时增加以动态平均容量为目标的回顾性静态对照 |

仅做分配时，无需任何实际到达量：

```python
from mobility_algorithms.geofencing import Candidate, required_capacity, allocate

candidates = [Candidate("synthetic-a", 0, 3), Candidate("synthetic-b", 1, 4)]
required = required_capacity(inventory=[1, 2], predicted_arrivals=[2, 1])
allocation = allocate(required, candidates, adjacency={0: [1], 1: [0]})
```

`theoretical_capacities(total_area_m2, unsuitable_fraction)` 对应式(22)，默认每车 2 m²，保留未取整理论值。`land_capacities(usable_area_m2)` 将可用面积换算成向下取整的整车容量；整数化是离散分配的实现约定，非论文新增公式。剔除零容量与不适宜地块后才能创建 Candidate。`microgrid_centers` 按 500/50 m 生成每格 100 个候选中心，土地适宜性及其输入由使用者在本地准备。

`empirical_capacities` 仅保留作扩展工具；论文使用土地筛选容量，不能用训练占用分位数替代式(22)。训练压力 95 分位只用于历史静态需求 `static_requirement`。

库存与调度现在形成反馈：深夜保留旧库存并累积到达，日间旧库存清空、新到达形成下一小时库存；调度转移更新下一小时各网格库存。论文未交代小时内事件先后，本实现要求显式选择“先按 B+A 评价压力，再周转，再调度留存库存”的时序，并将可搬运数量限制在留存库存内，以保持守恒。该时序应由实际实验配置进一步确认，不能从文章反推出唯一实现。

`spatial_coverage` 单独判断停车位置与激活围栏的距离是否 ≤100 m；有覆盖不等于有剩余容量。`simulate` 的 accommodation 是文稿所述的网格库存+到达压力容量比，不会把空间覆盖率当成容量容纳率。

式(28)单围栏占用率为 N/C；表2、表3的占用围栏比例为“非空激活围栏数/激活围栏总数”，再按小时平均。`fence_occupancy_metrics` 和仿真的 `mean_occupied_fence_share` 遵循后者；`capacity_utilization` 独立命名。未提供围栏级观测时不产生占用围栏比例。

## 6. 验证与发布

```bash
python -m unittest discover -s tests -v
python scripts/build_release.py --check
python scripts/build_release.py
```

未安装可选预测依赖时，其对应测试会跳过；完整验证请安装 `.[prediction]`。测试使用纯合成数据，覆盖时间边界、未来信息不影响当前决策、社区约束、单网格、零流量、围栏唯一分配、容量与调度守恒，以及神经网络/ARIMA 的运行。

发布工具生成 `dist/community-mobility-algorithms-source.zip`，只收录显式白名单中的代码和文档，并附 `SHA256SUMS.txt`。不会把 `data/`、`outputs/`、权重、缓存或原工作目录加入压缩包。发布前还会检查常见密钥和个人路径，但这不等于对任意新增内容进行自动匿名化。

上传 GitHub 时，将该 ZIP 解压到**新的空目录**，以其中的 `community-mobility-algorithms` 作为仓库根目录。不要在包含真实数据或论文文件的上级目录中初始化仓库。项目没有远程仓库地址，未执行自动上传。

详见 [逐公式核对与未报告细节](docs/ALGORITHMS.md) 和 [数据与发布边界](docs/PRIVACY.md)。

## 7. 适用范围

- 这是原研究代码的可移植算法整理版，未包含私有节点映射、真实数据清洗、论文图表和结果复现材料；不宣称可以还原论文数值。
- 围栏已实现小时库存及调度反馈，但仍是论文假设下的聚合仿真；没有模拟真实用户响应、道路路由或接入实时 GPS 服务。
- 相邻扩展按网格中心距离排序，调度使用贪心近邻；不保证全局最优。使用真实坐标运行时，衍生分配和预测结果仍可能包含敏感信息。
- 大型图和需求矩阵可能需要分块处理。本版相关矩阵和预生成窗口优先保证算法清晰，未提供大规模流式训练。

## 8. 许可证

算法代码使用 [MIT License](LICENSE)。许可证仅覆盖本仓库代码与说明，不授予任何私有数据、第三方数据、模型权重或论文材料的使用权。
