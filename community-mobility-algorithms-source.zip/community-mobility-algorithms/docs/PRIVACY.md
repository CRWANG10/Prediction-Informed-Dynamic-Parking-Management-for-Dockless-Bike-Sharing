# 数据边界与发布说明 / Privacy boundaries

## 当前发布内容

发布白名单只包含算法源代码、纯合成示例的生成代码、测试、README、构建配置、工作流和 MIT 许可证。不包含真实轨迹、车辆或用户标识、研究区域经纬度、原始工作簿、私有空间边界、论文文件、预测结果或训练权重。

示例使用固定随机种子和数学规则；格网与围栏 ID 均为合成标记。没有从真实数据抽样，也没有把真实数据变换或偏移后充当“合成数据”。

三个算法模块不会自动寻找数据文件，不使用网络服务，没有遥测或上传逻辑。命令行仅读取明确指定的本地 JSON，写入明确指定且尚不存在的结果文件。运行得到的结果是否敏感，取决于使用者提供的输入。

## 打包规则

`scripts/build_release.py` 使用逐文件白名单，不通过递归复制项目来构建 ZIP。`data/`、`private/`、`outputs/`、`results/`、`checkpoints/`、缓存、环境和 Git 历史永远不会被选入。符号链接及可疑个人路径、常见密钥格式会导致检查失败。每个打包文件均以实际字节计算 SHA-256。

新增代码或文档必须先审核，再显式加入白名单。不要在代码、注释、README、测试断言、图表、日志中硬编码真实记录、节点映射、区域边界或密钥。模式扫描不能证明任意内容已经匿名化，也无法识别所有业务敏感数据。

## GitHub 上传

将生成的源代码 ZIP 解压到新的空目录，以解压后的代码文件夹作为仓库根目录。不要将包含私有研究数据的父目录整体上传。不要强制添加被忽略的数据或模型文件。

`.gitignore` 只防止常规新增文件被跟踪，不会清除已经提交的历史。此次发布包是全新源代码快照，不包含已有 Git 历史。如自行使用旧仓库发布，需要另外检查其历史内容。

没有配置账号、个人邮箱、机构名称、远程地址或访问凭证。许可证只针对代码和说明；私有数据及第三方数据不随代码授权。

## English summary

The distributed snapshot contains source and documentation only. Synthetic examples are generated from mathematical rules and a fixed RNG seed, not sampled from real observations. No module uploads information or discovers datasets. Local outputs may still be sensitive when produced from private inputs.

The ZIP builder uses an explicit per-file allowlist and checks common credential/path patterns and symlinks. It does not anonymize arbitrary content. Git ignore rules do not remove already committed history. Publish the extracted snapshot from a new empty repository and review every new source/documentation change before adding it to the release allowlist.
