# Community Mobility Algorithms

[中文说明及完整接口](README.md)

Independent community detection, demand prediction and electronic fence allocation, aligned with the reported equations and settings in the revised manuscript. This repository contains only algorithm source, documentation and synthetic example generators. No real observations, locations, weights, manuscript file or empirical result tables are distributed.

## Reported settings

| Item | Setting |
| --- | --- |
| Prediction / micro grid | 500 m / 50 m; 10×10 microgrids per grid |
| Time step / history | 1 hour / 24 hours |
| Semantic neighbors | K=7; community vs global candidate pool, same per-community model fitting |
| Neural training | Adam, count-unit MSE, lr=.005, hidden=320, batch=64, dropout=.3, max epochs=150 |
| Neural seeds | 42, 123, 2024; metrics computed per seed, then mean and sample SD |
| Community RMSE | Mean of grid-level daily RMSEs, each over 24 hours |
| MAPE | Strictly positive observed demand only; no epsilon |
| Theoretical capacity | Eligible area / 2 m² per bicycle |
| Priority weights | Origin=.5, destination=.5 |
| Spatial coverage / relocation cost | 100 m / 4.1 CNY per bicycle-km |
| Night inventory retention | [00:00,06:00), clarified by the author during alignment |

Not every implementation detail is reported in the manuscript. Early-stopping patience and adjacency are explicit inputs. Within-hour turnover/dispatch ordering requires explicit acknowledgement. [The alignment notes](docs/ALGORITHMS.md) distinguish reported settings, author clarification, and implementation conventions; tests do not establish reproduction of private-data results.

## Install and run

Python 3.10–3.12 is recommended. In the repository root:

```bash
python -m venv .venv
# Activate for your shell, then:
python -m pip install -e .
python -m examples.synthetic_demo
python -m pip install -e ".[prediction]"
python -m examples.synthetic_demo --model irconv --epochs 2
```

The quick demo deliberately overrides history, K, hidden width and training epochs to run quickly. Its artificial 750 m adjacency radius is not a manuscript parameter. `naive` is a software demonstration, not a reported paper benchmark. Other model choices are `lstm`, `conv`, and `arima`. `conv` is a per-step spatial CNN followed by an ordinary LSTM, not a convolutional-gate LSTM cell; the paper does not fully specify this baseline's internals.

## Independent commands

```bash
python -m examples.synthetic_demo --write-inputs outputs/synthetic
python -m mobility_algorithms.community --input outputs/synthetic/community_input.json --output outputs/community_result.json
python -m mobility_algorithms.prediction --input outputs/synthetic/prediction_input.json --output outputs/prediction_result.json
python -m mobility_algorithms.geofencing --input outputs/synthetic/geofencing_input.json --output outputs/fence_result.json
```

Explicit local inputs and outputs only; existing results are never overwritten by algorithm commands. Imports do not scan datasets, train models or contact a network. Generated outputs are excluded from publication.

## Prediction protocol

`forecast(demand, split, labels, model="irconv", k=7, neighbor_scope="community", training=...)` performs one run. `demand` is a finite nonnegative T×N array on a regular time axis. Use the same community labels for both scopes; `neighbor_scope="global"` expands only neighbor eligibility. Inputs are standardized with training-only statistics. The regression head uses only the final LSTM hidden state, as in Equation (17), without an additional grid embedding. Training/validation MSE is measured in original arrival units.

`run_paper_protocol(demand, labels, model=..., training={"patience": chosen_patience}, neighbor_scope=...)` requires 168 hourly rows and a fixed partition derived only from the first 72 hours. Three exclusive train/validation/test boundaries are 72/96/120, 96/120/144, and 120/144/168. The function does not refit the community partition or force a particular number of communities. Neural models use the three reported seeds; only allocation inputs average predictions. Reporting averages seed-level metrics and uses sample SD (ddof=1). ARIMA is single-fit per grid, selected by training AIC among the five orders stated in Section 5.2.

The command-line flag `--paper-protocol` selects this function. Inputs then omit `split` and `k`. Patience must be specified, because its value was not reported. Ordinary `forecast` uses no early termination when patience is None, but retains the best validation checkpoint in memory. Evaluation is rolling one-step with previously observed history.

For matrix inputs `metrics["RMSE"]` averages the square root separately computed over each grid's time series. `MAPE` uses positive targets only and returns None when none exist. Pooled RMSE is explicitly named as a diagnostic. Community averages are equally weighted.

## Fence interface and semantics

`simulate` takes `initial_inventory` (N), `predicted_arrivals` / `actual_arrivals` (H×N), `candidates`, and projected `centers_m` (N×2). Candidates contain unique `fence_id`, `grid_id`, positive integer `capacity`, and training-only origin/destination activity. Supply either adjacency or a radius explicitly; no radius is invented from the manuscript. Cost defaults to 4.1 CNY/bicycle-km. Night hours default to 0–5 inclusive.

The manuscript does not specify the within-hour ordering of turnover and relocation. This implementation requires `turnover_dispatch_order="turnover_then_dispatch"`: evaluate B+arrivals pressure, clear carried daytime stock (retain all night stock), dispatch retained bicycles, and use the resulting spatial inventory next hour. Transfer volume is limited to retained stock, preventing negative inventory or fabricated bicycles. This is a disclosed completion of an unspecified detail, not a uniquely established manuscript ordering.

Static layouts are selected once and remain fixed; all strategies use inventory feedback. `static_required` is training-pressure q95. `include_matched_static=True` creates a retrospective fixed-capacity control against the dynamic mean capacity, reporting the remaining discrete gap. The expansion-based matcher requires the dynamic mean to be at least the historical baseline capacity.

`theoretical_capacities` returns Equation (22) unrounded. `land_capacities` discretizes usable area / 2 into whole-bike capacities. Candidate land suitability must be checked upstream. Empirical occupancy-quantile capacities are supplementary utilities, not a replacement for the paper's land-based capacities.

`spatial_coverage` uses the 100 m distance criterion separately from grid-pressure capacity accommodation. `fence_occupancy_metrics` distinguishes per-fence N/C from the occupied-fence share (nonempty active fences / all active fences). Supply actual per-fence counts through `observed_fence_occupancy`; absent observations yield no invented occupancy-share metric. Grid-level capacity utilization is separately named. Relocation costs count assigned transfers, not repeated unresolved observations.

## Validate and publish

```bash
python -m unittest discover -s tests -v
python scripts/build_release.py --check
python scripts/build_release.py
```

Install the prediction extra for full tests; missing optional dependencies otherwise skip their checks. The builder uses an explicit source/documentation allowlist, common credential/path checks and a SHA256 manifest. No input data, outputs, caches, weights or parent directories are packaged. Publish only the extracted source project in a new repository. See [privacy boundaries](docs/PRIVACY.md).

## License

[MIT](LICENSE), covering repository code/documentation only, with no license to private or third-party data or manuscript materials.
