"""Examples generated entirely from mathematical rules and a fixed random seed."""
