"""Shared array validation; no dataset discovery or file access."""
import numpy as np


def nonnegative(value, name, ndim=None):
    array = np.asarray(value, dtype=float)
    if ndim is not None and array.ndim != ndim:
        raise ValueError(f"{name} must have {ndim} dimensions")
    if array.size == 0 or not np.isfinite(array).all() or (array < 0).any():
        raise ValueError(f"{name} must be nonempty, finite and nonnegative")
    return array


def positive_integer(value, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, (int, np.integer)) or value < 1:
        raise ValueError(f"{name} must be a positive integer")
    return int(value)

