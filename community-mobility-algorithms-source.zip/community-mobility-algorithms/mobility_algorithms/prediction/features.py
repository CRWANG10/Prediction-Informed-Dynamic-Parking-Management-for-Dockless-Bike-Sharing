"""Chronological windows and training-only semantic neighborhoods."""
from dataclasses import dataclass
import numpy as np
from .._validation import nonnegative, positive_integer


@dataclass(frozen=True)
class Split:
    """Exclusive integer boundaries on the time axis (regular time steps)."""
    train_end: int
    validation_end: int
    history: int = 24

    def validate(self, n_steps):
        for key in ("history", "train_end", "validation_end"):
            positive_integer(getattr(self, key), key)
        if not self.history < self.train_end < self.validation_end < n_steps:
            raise ValueError("Require history < train_end < validation_end < n_steps")


def semantic_neighbors(train_demand, k=7, labels=None, equal_weights=False):
    """Rank same-community neighbors by Pearson correlation of training values.

    Nonpositive correlations receive zero weight when positive weights exist;
    otherwise selected neighbors share equal weights. Empty slots use -1/0.
    """
    train = nonnegative(train_demand, "train_demand", 2)
    positive_integer(k, "k")
    n = train.shape[1]
    if train.shape[0] < 2:
        raise ValueError("At least two training time steps are required")
    labels = np.zeros(n, dtype=int) if labels is None else np.asarray(labels)
    if labels.shape != (n,) or labels.dtype.kind not in "iu" or (labels < 0).any():
        raise ValueError("labels must be nonnegative integer community labels")
    centered = train - train.mean(axis=0)
    norm = np.sqrt((centered * centered).sum(axis=0))
    denominator = norm[:, None] * norm[None, :]
    corr = np.divide(centered.T @ centered, denominator,
                     out=np.zeros((n, n)), where=denominator > 0)
    corr = np.clip(corr, -1, 1)
    ids = np.full((n, k), -1, dtype=np.int64)
    weights = np.zeros((n, k), dtype=np.float32)
    for target in range(n):
        candidates = [j for j in range(n) if j != target and labels[j] == labels[target]]
        selected = sorted(candidates, key=lambda j: (-corr[target, j], j))[:k]
        if not selected:
            continue
        raw = np.maximum(corr[target, selected], 0.0)
        if equal_weights or raw.sum() <= 0:
            raw = np.ones(len(selected))
        ids[target, :len(selected)] = selected
        weights[target, :len(selected)] = raw / raw.sum()
    return ids, weights


def make_features(demand, split, mode="irconv", lattice=None, neighbor_ids=None, neighbor_weights=None,
                  target_grid_ids=None):
    """Return windows with target, aggregate and K individual weighted channels.

    Windows at t use only [t-history, t); validation/test use earlier observed
    values (rolling one-step evaluation, not open-loop multi-step forecasting).
    """
    demand = nonnegative(demand, "demand", 2)
    split.validate(len(demand))
    n_grids = demand.shape[1]
    targets = np.arange(n_grids) if target_grid_ids is None else np.asarray(target_grid_ids)
    if (targets.ndim != 1 or targets.size == 0 or targets.dtype.kind not in "iu"
            or (targets < 0).any() or (targets >= n_grids).any()
            or len(np.unique(targets)) != len(targets)):
        raise ValueError("target_grid_ids must be unique, valid integer grid indices")
    if mode not in {"lstm", "conv", "irconv"}:
        raise ValueError("mode must be lstm, conv or irconv")
    mean = demand[:split.train_end].mean(axis=0)
    std = demand[:split.train_end].std(axis=0)
    std[std < 1e-6] = 1.0
    scaled = (demand - mean) / std
    if mode == "conv":
        lattice = np.asarray(lattice)
        if lattice.shape != (n_grids, 2) or lattice.dtype.kind not in "iu":
            raise ValueError("conv requires an integer N x 2 lattice")
        lookup = {tuple(coord): i for i, coord in enumerate(lattice)}
        if len(lookup) != n_grids:
            raise ValueError("lattice cells must be unique")
    if mode == "irconv":
        ids, weights = np.asarray(neighbor_ids), np.asarray(neighbor_weights, dtype=float)
        if ids.ndim != 2 or ids.shape[0] != n_grids or ids.shape != weights.shape:
            raise ValueError("neighbor ids and weights must have matching N x K shapes")
        if ids.dtype.kind not in "iu" or (ids < -1).any() or (ids >= n_grids).any():
            raise ValueError("Invalid neighbor indices")
        nonnegative(weights, "neighbor_weights", 2)
        if (weights[ids < 0] != 0).any():
            raise ValueError("Padded neighbor weights must be zero")
        for target in range(n_grids):
            valid_ids = ids[target, ids[target] >= 0]
            if target in valid_ids or len(np.unique(valid_ids)) != len(valid_ids):
                raise ValueError("Neighbors must be unique and exclude the target")
            expected_sum = 1.0 if len(valid_ids) else 0.0
            if not np.isclose(weights[target].sum(), expected_sum):
                raise ValueError("Neighbor weights must sum to one (or zero for a singleton)")
    result = {"normalization": (mean.astype(np.float32), std.astype(np.float32))}
    boundaries = [("train", split.history, split.train_end),
                  ("validation", split.train_end, split.validation_end),
                  ("test", split.validation_end, len(demand))]
    for name, start, end in boundaries:
        times = np.repeat(np.arange(start, end), len(targets))
        grids = np.tile(targets, end - start)
        shape = (3, 3) if mode == "conv" else ((1,) if mode == "lstm" else (ids.shape[1] + 2,))
        x = np.zeros((len(times), split.history, *shape), dtype=np.float32)
        for row, (t, g) in enumerate(zip(times, grids)):
            window = scaled[t-split.history:t]
            if mode == "lstm":
                x[row, :, 0] = window[:, g]
            elif mode == "conv":
                gx, gy = lattice[g]
                for iy, dy in enumerate((-1, 0, 1)):
                    for ix, dx in enumerate((-1, 0, 1)):
                        j = lookup.get((gx + dx, gy + dy))
                        if j is not None:
                            x[row, :, iy, ix] = window[:, j]
            else:
                x[row, :, 0] = window[:, g]
                valid = np.flatnonzero(ids[g] >= 0)
                if len(valid):
                    weighted = window[:, ids[g, valid]] * weights[g, valid]
                    x[row, :, 1] = weighted.sum(axis=1)
                    for column, slot in enumerate(valid):
                        x[row, :, slot + 2] = weighted[:, column]
        y = ((demand[times, grids] - mean[grids]) / std[grids]).astype(np.float32)
        result[name] = (x, y, grids.astype(np.int64), times.astype(np.int64))
    return result

