"""Per-community forecasting, independent of the community detection module."""
from dataclasses import dataclass, asdict
import numpy as np
from .features import Split, make_features, semantic_neighbors
from .metrics import metrics, community_metrics, seed_metric_summary
from .._validation import nonnegative, positive_integer


@dataclass(frozen=True)
class TrainingConfig:
    hidden_units: int = 320
    learning_rate: float = 0.005
    dropout: float = 0.3
    batch_size: int = 64
    loss: str = "MSE"
    max_epochs: int = 150
    # The manuscript does not specify patience: never label an invented value
    # as a paper setting. None runs all epochs and retains best validation MSE.
    patience: int | None = None
    seed: int = 42

    def validate(self):
        for name in ("hidden_units", "batch_size", "max_epochs"):
            positive_integer(getattr(self, name), name)
        if self.patience is not None:
            positive_integer(self.patience, "patience")
        if not np.isfinite(self.learning_rate) or self.learning_rate <= 0:
            raise ValueError("learning_rate must be positive")
        if not 0 <= self.dropout < 1:
            raise ValueError("dropout must be in [0, 1)")
        if self.loss != "MSE":
            raise ValueError("The manuscript protocol uses MSE loss")
        if not isinstance(self.seed, int) or not 0 <= self.seed < 2**32:
            raise ValueError("seed must be an integer in [0, 2**32)")


def forecast(demand, split, labels=None, model="irconv", k=7, lattice=None, training=None,
             neighbor_scope="community"):
    """Train independent models per community; return aligned rolling predictions.

    Keep labels fixed for a scope comparison. Only neighbor_scope changes;
    global neighbors may cross boundaries while model fitting remains per community.
    No module infers, reads or writes a private dataset.
    """
    demand = nonnegative(demand, "demand", 2)
    split = Split(**split) if isinstance(split, dict) else split
    split.validate(len(demand))
    positive_integer(k, "k")
    if neighbor_scope not in {"community", "global"}:
        raise ValueError("neighbor_scope must be community or global")
    config = TrainingConfig(**(training or {})) if isinstance(training, (dict, type(None))) else training
    config.validate()
    if model not in {"lstm", "conv", "irconv", "arima", "naive"}:
        raise ValueError("model must be lstm, conv, irconv, arima or naive")
    n = demand.shape[1]
    labels = np.ones(n, dtype=int) if labels is None else np.asarray(labels)
    if labels.shape != (n,) or labels.dtype.kind not in "iu" or (labels < 0).any():
        raise ValueError("Provide nonnegative integer labels aligned with demand columns; remove excluded grids first")
    if model == "conv":
        lattice = np.asarray(lattice)
        if lattice.shape != (n, 2) or lattice.dtype.kind not in "iu":
            raise ValueError("conv requires an integer lattice of shape N x 2")
        if len({tuple(row) for row in lattice}) != n:
            raise ValueError("lattice cells must be unique")
    val = np.empty((split.validation_end-split.train_end, n))
    test = np.empty((len(demand)-split.validation_end, n))
    diagnostics = []
    if model == "irconv":
        ids, weights = semantic_neighbors(demand[:split.train_end], k=k,
            labels=labels if neighbor_scope == "community" else None)
    for label in np.unique(labels):
        grids = np.flatnonzero(labels == label)
        local = demand[:, grids]
        if model == "naive":
            predicted = local[split.train_end-1:-1]
            size = split.validation_end-split.train_end
            local_val, local_test = predicted[:size], predicted[size:]
            detail = {"method": "previous observed time step"}
        elif model == "arima":
            from .arima import rolling_arima
            run = rolling_arima(local, split)
            local_val, local_test = run["validation"], run["test"]
            detail = {"orders": run["orders"]}
        else:
            from .training import train_model
            features = make_features(demand, split, model,
                                     lattice=lattice if model == "conv" else None,
                                     neighbor_ids=ids if model == "irconv" else None,
                                     neighbor_weights=weights if model == "irconv" else None,
                                     target_grid_ids=grids)
            params = {name: getattr(config, name) for name in
                      ("hidden_units", "learning_rate", "dropout", "batch_size", "loss")}
            model_name = {"lstm": "LSTM", "conv": "ConvLSTM", "irconv": "Community-IrConv+LSTM"}[model]
            run = train_model(model_name, features, params, config.seed,
                              config.max_epochs, config.patience)
            local_val = run["predictions"]["validation"]["pred"].reshape(-1, len(grids))
            local_test = run["predictions"]["test"]["pred"].reshape(-1, len(grids))
            detail = {"epochs_run": run["epochs_run"], "history": run["history"],
                      "parameter_count": run["parameter_count"]}
            if model == "irconv":
                detail["neighbor_ids_global"] = ids[grids]
                detail["neighbor_weights"] = weights[grids]
        if not np.isfinite(local_val).all() or not np.isfinite(local_test).all():
            raise RuntimeError("Model produced nonfinite predictions")
        val[:, grids], test[:, grids] = local_val, local_test
        diagnostics.append({"community": int(label), "grid_indices": grids, **detail})
    return {"model": model, "neighbor_scope": neighbor_scope, "validation": val, "test": test,
            "test_start_index": split.validation_end,
            "validation_metrics": metrics(demand[split.train_end:split.validation_end], val),
            "test_metrics": metrics(demand[split.validation_end:], test),
            "validation_community_metrics": community_metrics(demand[split.train_end:split.validation_end], val, labels),
            "test_community_metrics": community_metrics(demand[split.validation_end:], test, labels),
            "training_config": asdict(config),
            "communities": diagnostics, "evaluation": "rolling one-step with observed history"}


def run_paper_protocol(demand, labels, model="irconv", lattice=None, training=None,
                       neighbor_scope="community"):
    """Section 5.2: fixed first-three-day partition, three daily expanding splits.

    demand contains exactly seven days of hourly arrivals. labels must already
    have been derived exclusively from the first 72 hours. This function never
    recomputes that partition. Early-stopping patience is explicit because the
    manuscript does not report its value. No real dates or data are embedded.
    """
    demand = nonnegative(demand, "demand", 2)
    if len(demand) != 168:
        raise ValueError("The paper protocol requires seven complete days (168 hours)")
    if model not in {"irconv", "lstm", "conv", "arima"}:
        raise ValueError("Paper comparisons include irconv, lstm, conv and arima")
    config = dict(training or {})
    locked = {"hidden_units": 320, "learning_rate": 0.005, "dropout": 0.3,
              "batch_size": 64, "max_epochs": 150, "loss": "MSE"}
    for name, value in locked.items():
        if name in config and config[name] != value:
            raise ValueError(f"Paper protocol requires {name}={value}; use forecast for experiments")
    if "seed" in config:
        raise ValueError("Paper neural seeds are fixed to 42, 123 and 2024")
    if model != "arima" and config.get("patience") is None:
        raise ValueError("Supply training.patience explicitly; its value is not reported in the manuscript")
    scenarios = []
    for train_end, validation_end, test_end in ((72, 96, 120), (96, 120, 144), (120, 144, 168)):
        seeds = (42,) if model == "arima" else (42, 123, 2024)
        runs = [forecast(demand[:test_end], Split(train_end, validation_end, 24), labels,
                         model=model, k=7, lattice=lattice, neighbor_scope=neighbor_scope,
                         training={**locked, **config, "seed": seed}) for seed in seeds]
        scenarios.append({"train_end": train_end, "validation_end": validation_end,
                          "test_end": test_end, "seeds": list(seeds) if model != "arima" else [],
                          "seed_community_metrics": [run["test_community_metrics"] for run in runs],
                          "community_metric_summary": seed_metric_summary([run["test_community_metrics"] for run in runs]),
                          "allocation_predictions": np.mean([run["test"] for run in runs], axis=0)})
    return {"model": model, "neighbor_scope": neighbor_scope, "scenarios": scenarios,
            "partition_training_hours": 72, "history": 24, "K": 7,
            "forecast_averaging_use": "allocation only; metrics are computed separately per seed"}

