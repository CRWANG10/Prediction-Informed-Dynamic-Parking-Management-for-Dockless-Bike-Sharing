"""Training-AIC selection and rolling one-step ARIMA baseline."""
import warnings
import numpy as np
from .._validation import nonnegative, positive_integer


def rolling_arima(demand, split, seasonal_lag=24, orders=None):
    from statsmodels.tsa.arima.model import ARIMA
    demand = nonnegative(demand, "demand", 2)
    split.validate(len(demand))
    positive_integer(seasonal_lag, "seasonal_lag")
    orders = orders or [(0, 0, 0), (1, 0, 0), (1, 0, 1), (1, 1, 0), (0, 1, 1)]
    predictions = np.empty((len(demand) - split.train_end, demand.shape[1]))
    diagnostics = []
    for grid in range(demand.shape[1]):
        series = demand[:, grid]
        fitted, chosen, aic = None, None, float("inf")
        for order in orders:
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    candidate = ARIMA(series[:split.train_end], order=order).fit()
                if np.isfinite(candidate.aic) and candidate.aic < aic:
                    fitted, chosen, aic = candidate, order, float(candidate.aic)
            except (ValueError, RuntimeError, np.linalg.LinAlgError):
                continue
        fallback_steps = 0
        for t in range(split.train_end, len(series)):
            fallback = series[t-seasonal_lag] if t >= seasonal_lag else series[t-1]
            try:
                value = float(fitted.forecast(1)[0]) if fitted is not None else float("nan")
            except (ValueError, RuntimeError, np.linalg.LinAlgError):
                value = float("nan")
            if not np.isfinite(value):
                value = fallback
                fallback_steps += 1
            predictions[t-split.train_end, grid] = max(value, 0)
            # Reveal the current observation only AFTER forecasting that step.
            if fitted is not None:
                try:
                    fitted = fitted.append([series[t]], refit=False)
                except (ValueError, RuntimeError, np.linalg.LinAlgError):
                    fitted = None
        diagnostics.append({"grid_index": grid, "order": chosen,
                            "training_aic": aic if np.isfinite(aic) else None,
                            "fallback_steps": fallback_steps})
    size = split.validation_end - split.train_end
    return {"validation": predictions[:size], "test": predictions[size:], "orders": diagnostics}

