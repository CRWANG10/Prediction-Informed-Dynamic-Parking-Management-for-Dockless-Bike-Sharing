import argparse
from .._io import read_json, write_json
from . import forecast, run_paper_protocol


def main():
    parser = argparse.ArgumentParser(description="Independent community-aware rolling demand forecasting")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--paper-protocol", action="store_true", help="Three daily scenarios with the manuscript parameters")
    args = parser.parse_args()
    run = run_paper_protocol if args.paper_protocol else forecast
    write_json(args.output, run(**read_json(args.input)))


if __name__ == "__main__":
    main()
