"""Equation (9) IrConv and Equation (17) hidden-state-only regression heads."""
import torch
from torch import nn


class LSTMRegressor(nn.Module):
    def __init__(self, hidden: int, dropout: float, n_grids: int):
        super().__init__()
        self.lstm = nn.LSTM(1, hidden, batch_first=True)
        self.head = nn.Sequential(nn.Dropout(dropout), nn.Linear(hidden, 1))

    def forward(self, x: torch.Tensor, grid_ids: torch.Tensor) -> torch.Tensor:
        _, (hidden, _) = self.lstm(x)
        return self.head(hidden[-1]).squeeze(1)


class ConvLSTMRegressor(nn.Module):
    def __init__(self, hidden: int, dropout: float, n_grids: int):
        super().__init__()
        self.spatial = nn.Sequential(nn.Conv2d(1, 16, kernel_size=3, padding=0), nn.ReLU())
        self.lstm = nn.LSTM(16, hidden, batch_first=True)
        self.head = nn.Sequential(nn.Dropout(dropout), nn.Linear(hidden, 1))

    def forward(self, x: torch.Tensor, grid_ids: torch.Tensor) -> torch.Tensor:
        batch, steps, height, width = x.shape
        spatial = self.spatial(x.reshape(batch * steps, 1, height, width)).reshape(batch, steps, 16)
        _, (hidden, _) = self.lstm(spatial)
        return self.head(hidden[-1]).squeeze(1)


class IrConvLSTMRegressor(nn.Module):
    def __init__(self, input_dim: int, hidden: int, dropout: float, n_grids: int):
        super().__init__()
        self.target_transform = nn.Linear(1, 16, bias=True)
        self.neighbor_transform = nn.Linear(max(input_dim - 1, 1), 16, bias=False)
        self.activation = nn.ReLU()
        self.lstm = nn.LSTM(16, hidden, batch_first=True)
        self.head = nn.Sequential(nn.Dropout(dropout), nn.Linear(hidden, 1))

    def forward(self, x: torch.Tensor, grid_ids: torch.Tensor) -> torch.Tensor:
        target = self.target_transform(x[:, :, :1])
        neighbors = x[:, :, 1:]
        if neighbors.shape[-1] == 0:
            neighbors = torch.zeros_like(x[:, :, :1])
        spatial = self.activation(target + self.neighbor_transform(neighbors))
        _, (hidden, _) = self.lstm(spatial)
        return self.head(hidden[-1]).squeeze(1)
