"""Manuscript Equations (19)-(21): average grid RMSE, positive-demand MAPE."""
import numpy as np
from .._validation import nonnegative


def metrics(y_true, y_pred):
    """Time x grid arrays; a vector is one grid's time series.

    RMSE takes the square root PER GRID, then averages equally over grids.
    MAPE includes strictly positive observations only, with no epsilon.
    """
    true = nonnegative(y_true, "y_true")
    pred = np.asarray(y_pred, dtype=float)
    if true.ndim not in (1, 2) or pred.shape != true.shape or not np.isfinite(pred).all():
        raise ValueError("Inputs must be matching finite time x grid matrices or time vectors")
    if true.ndim == 1:
        true, pred = true[:, None], pred[:, None]
    error = np.clip(pred, 0, None) - true
    absolute = np.abs(error)
    nz = true > 0
    mape = float((absolute[nz] / true[nz]).mean() * 100) if nz.any() else None
    return {"MAE": float(absolute.mean()), "MSE": float(np.square(error).mean()),
            "RMSE": float(np.sqrt(np.square(error).mean(axis=0)).mean()),
            "RMSE_pooled_diagnostic": float(np.sqrt(np.square(error).mean())),
            "MAPE": mape, "MAPE_nonzero": mape,
            "zero_demand_ratio": float((true == 0).mean()),
            "n_observations": int(true.size), "n_positive_observations": int(nz.sum()),
            "n_grids": int(true.shape[1]), "n_time_steps": int(true.shape[0])}


def community_metrics(y_true, y_pred, labels):
    true = nonnegative(y_true, "y_true", 2)
    pred = np.asarray(y_pred, dtype=float)
    labels = np.asarray(labels)
    if pred.shape != true.shape or labels.shape != (true.shape[1],):
        raise ValueError("Predictions and community labels must align with grid columns")
    rows = [{"community": int(label), **metrics(true[:, labels == label], pred[:, labels == label])}
            for label in np.unique(labels)]
    macro = {}
    for key in ("MAE", "RMSE", "MAPE", "MSE"):
        values = [row[key] for row in rows if row[key] is not None]
        macro[key] = float(np.mean(values)) if values else None
    return {"by_community": rows, "equal_community_mean": macro}


def seed_metric_summary(seed_results):
    """Average seed-level metrics, never metrics of the averaged forecasts."""
    if not seed_results:
        raise ValueError("At least one seed result is required")
    rows = []
    expected = [row["community"] for row in seed_results[0]["by_community"]]
    for result in seed_results:
        if [row["community"] for row in result["by_community"]] != expected:
            raise ValueError("Community order differs across seeds")
    for index, label in enumerate(expected):
        row = {"community": label}
        for key in ("MAE", "RMSE", "MAPE"):
            values = [result["by_community"][index][key] for result in seed_results]
            if any(value is None for value in values):
                row[key] = {"mean": None, "sample_std": None}
            else:
                row[key] = {"mean": float(np.mean(values)),
                            "sample_std": float(np.std(values, ddof=1)) if len(values) > 1 else None}
        rows.append(row)
    return rows
