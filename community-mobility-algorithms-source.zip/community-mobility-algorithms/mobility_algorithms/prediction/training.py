"""CPU training with validation early stopping; no checkpoints or disk I/O."""
import os
import random
import time
import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader, TensorDataset
from .models import LSTMRegressor, ConvLSTMRegressor, IrConvLSTMRegressor


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def train_model(
    model_name: str,
    features: dict,
    params: dict,
    seed: int,
    max_epochs: int,
    patience: int | None,
    min_delta: float = 0.0,
) -> dict:
    set_seed(seed)
    torch.set_num_threads(min(8, os.cpu_count() or 1))
    n_grids = len(features["normalization"][0])
    input_dim = int(features["train"][0].shape[-1])
    if model_name == "LSTM":
        model = LSTMRegressor(params["hidden_units"], params["dropout"], n_grids)
    elif model_name == "ConvLSTM":
        model = ConvLSTMRegressor(params["hidden_units"], params["dropout"], n_grids)
    elif model_name == "Community-IrConv+LSTM":
        model = IrConvLSTMRegressor(input_dim, params["hidden_units"], params["dropout"], n_grids)
    else:
        raise ValueError(model_name)
    optimizer = torch.optim.Adam(model.parameters(), lr=params["learning_rate"])
    loss_name = params.get("loss", "MSE")
    if loss_name == "MSE":
        criterion = nn.MSELoss()
    elif loss_name == "Huber":
        criterion = nn.SmoothL1Loss(beta=1.0)
    elif loss_name == "MAE":
        criterion = nn.L1Loss()
    else:
        raise ValueError(f"Unsupported loss: {loss_name}")
    # Equation (18) is MSE in arrival-count units. Center offsets cancel in
    # the loss; restoring each grid's scale avoids inverse-variance weighting.
    mean, std = features["normalization"]
    scale = torch.from_numpy(std)

    def count_loss(predicted, observed, grids):
        return criterion(predicted * scale[grids], observed * scale[grids])

    def loader(split: str, shuffle: bool) -> DataLoader:
        x, y, grids, times = features[split]
        ds = TensorDataset(
            torch.from_numpy(x), torch.from_numpy(y), torch.from_numpy(grids), torch.from_numpy(times)
        )
        generator = torch.Generator().manual_seed(seed)
        return DataLoader(
            ds,
            batch_size=params["batch_size"],
            shuffle=shuffle,
            generator=generator,
            num_workers=0,
        )

    best_state = None
    best_loss = float("inf")
    stale = 0
    history = []
    started = time.perf_counter()
    for epoch in range(1, max_epochs + 1):
        model.train()
        train_sum = 0.0
        train_n = 0
        for xb, yb, gb, _ in loader("train", True):
            optimizer.zero_grad(set_to_none=True)
            prediction = model(xb, gb)
            loss = count_loss(prediction, yb, gb)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            optimizer.step()
            train_sum += float(loss.item()) * len(xb)
            train_n += len(xb)
        model.eval()
        val_sum = 0.0
        val_n = 0
        with torch.no_grad():
            for xb, yb, gb, _ in loader("validation", False):
                loss = count_loss(model(xb, gb), yb, gb)
                val_sum += float(loss.item()) * len(xb)
                val_n += len(xb)
        val_loss = val_sum / max(val_n, 1)
        history.append(
            {"epoch": epoch, "training_MSE_counts": train_sum / max(train_n, 1), "validation_grid_MSE_counts": val_loss}
        )
        if val_loss < best_loss - min_delta:
            best_loss = val_loss
            best_state = {key: value.detach().clone() for key, value in model.state_dict().items()}
            stale = 0
        else:
            stale += 1
            if patience is not None and stale >= patience:
                break
    training_seconds = time.perf_counter() - started
    if best_state is not None:
        model.load_state_dict(best_state)

    mean, std = features["normalization"]
    predictions = {}
    for split in ("validation", "test"):
        parts = []
        true_parts = []
        grid_parts = []
        time_parts = []
        begin = time.perf_counter()
        model.eval()
        with torch.no_grad():
            for xb, yb, gb, tb in loader(split, False):
                parts.append(model(xb, gb).cpu().numpy())
                true_parts.append(yb.numpy())
                grid_parts.append(gb.numpy())
                time_parts.append(tb.numpy())
        pred_scaled = np.concatenate(parts)
        true_scaled = np.concatenate(true_parts)
        grids = np.concatenate(grid_parts)
        times = np.concatenate(time_parts)
        predictions[split] = {
            "true": np.clip(true_scaled * std[grids] + mean[grids], 0.0, None),
            "pred": np.clip(pred_scaled * std[grids] + mean[grids], 0.0, None),
            "grid_ids": grids,
            "time_ids": times,
            "inference_seconds": time.perf_counter() - begin,
        }
    return {
        "model": model_name,
        "seed": seed,
        "params": params,
        "best_validation_grid_MSE_counts": best_loss,
        "epochs_run": len(history),
        "training_seconds": training_seconds,
        "parameter_count": int(sum(p.numel() for p in model.parameters() if p.requires_grad)),
        "history": history,
        "predictions": predictions,
    }
