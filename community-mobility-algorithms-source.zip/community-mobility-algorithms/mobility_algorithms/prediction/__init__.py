"""Independent forecasting APIs. Neural dependencies are imported on demand."""
from .features import Split, make_features, semantic_neighbors
from .metrics import metrics, community_metrics, seed_metric_summary


def forecast(*args, **kwargs):
    from .pipeline import forecast as run
    return run(*args, **kwargs)


def run_paper_protocol(*args, **kwargs):
    from .pipeline import run_paper_protocol as run
    return run(*args, **kwargs)


__all__ = ["Split", "make_features", "semantic_neighbors", "metrics", "community_metrics",
           "seed_metric_summary", "forecast", "run_paper_protocol"]

