"""Data-free algorithms. Importing this package performs no I/O or training."""

__version__ = "0.2.0"

