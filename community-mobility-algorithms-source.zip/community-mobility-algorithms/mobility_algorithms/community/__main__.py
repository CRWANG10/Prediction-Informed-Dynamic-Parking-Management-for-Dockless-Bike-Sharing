import argparse
from .._io import read_json, write_json
from . import detect_communities


def main():
    parser = argparse.ArgumentParser(description="Directed weighted Louvain (training OD only)")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    result = detect_communities(**read_json(args.input))
    write_json(args.output, result)


if __name__ == "__main__":
    main()
