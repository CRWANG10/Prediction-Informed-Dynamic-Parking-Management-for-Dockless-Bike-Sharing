"""Louvain partitioning of a directed weighted, training-period OD network."""
import numpy as np
import networkx as nx
from .._validation import nonnegative, positive_integer


def grid_indices(points_m, cell_size_m=500.0, origin_m=(0.0, 0.0)):
    """Bin projected metre coordinates using an explicit, fixed grid origin.

    Inputs are NOT longitude/latitude. Projection and any private coordinate
    conversion are the caller's responsibility. Returns integer (x, y) cells.
    """
    points = np.asarray(points_m, dtype=float)
    origin = np.asarray(origin_m, dtype=float)
    if points.ndim != 2 or points.shape[1] != 2 or origin.shape != (2,):
        raise ValueError("points_m must be N x 2 and origin_m must have length 2")
    if not np.isfinite(points).all() or not np.isfinite(origin).all():
        raise ValueError("Coordinates must be finite")
    if not np.isfinite(cell_size_m) or cell_size_m <= 0:
        raise ValueError("cell_size_m must be positive")
    return np.floor((points - origin) / cell_size_m).astype(np.int64)


def aggregate_arrivals(time_indices, grid_ids, n_steps, n_grids):
    """Aggregate caller-supplied integer time/grid indices; no identifiers needed."""
    positive_integer(n_steps, "n_steps")
    positive_integer(n_grids, "n_grids")
    t, g = np.asarray(time_indices), np.asarray(grid_ids)
    if t.ndim != 1 or t.shape != g.shape:
        raise ValueError("time_indices and grid_ids must be equal-length vectors")
    if t.size and (t.dtype.kind not in "iu" or g.dtype.kind not in "iu"):
        raise ValueError("Indices must be integers")
    if (t < 0).any() or (t >= n_steps).any() or (g < 0).any() or (g >= n_grids).any():
        raise ValueError("Index out of bounds")
    result = np.zeros((n_steps, n_grids), dtype=float)
    np.add.at(result, (t.astype(int), g.astype(int)), 1)
    return result


def detect_communities(n_grids, edges, resolution=1.0, seed=42, min_size=1):
    """Return labels, modularity and small-community mask.

    edges: (source_index, destination_index, nonnegative_flow) triples built
    ONLY from training observations. Duplicate edges are summed. Self loops
    are retained, as in the source algorithm. Small communities receive label
    -1 without deleting or reordering any input grid.
    """
    positive_integer(n_grids, "n_grids")
    positive_integer(min_size, "min_size")
    if not np.isfinite(resolution) or resolution <= 0:
        raise ValueError("resolution must be positive")
    graph = nx.DiGraph()
    graph.add_nodes_from(range(n_grids))
    for source, target, flow in edges:
        if (isinstance(source, bool) or isinstance(target, bool)
                or not isinstance(source, (int, np.integer))
                or not isinstance(target, (int, np.integer))
                or not 0 <= source < n_grids or not 0 <= target < n_grids):
            raise ValueError("Edge indices must be integers in [0, n_grids)")
        flow = float(nonnegative([flow], "flow")[0])
        if flow:
            prior = graph.get_edge_data(source, target, {}).get("weight", 0.0)
            graph.add_edge(int(source), int(target), weight=prior + flow)
    if graph.number_of_edges() == 0:
        groups = [{node} for node in graph]
        modularity = 0.0  # Explicit convention: modularity is undefined at zero flow.
    else:
        groups = nx.community.louvain_communities(
            graph, weight="weight", resolution=resolution, seed=seed
        )
        modularity = float(nx.community.modularity(
            graph, groups, weight="weight", resolution=resolution
        ))
    groups = sorted(groups, key=lambda group: (-len(group), min(group)))
    labels = np.full(n_grids, -1, dtype=int)
    for label, members in enumerate(groups, start=1):
        if len(members) >= min_size:
            labels[list(members)] = label
    return {"labels": labels, "modularity": modularity, "retained": labels >= 0,
            "community_count_before_filter": len(groups)}

