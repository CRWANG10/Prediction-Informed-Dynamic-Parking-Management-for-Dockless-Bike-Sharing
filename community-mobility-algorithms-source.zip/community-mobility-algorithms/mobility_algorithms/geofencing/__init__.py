"""Electronic fence allocation independent of graph detection and forecasting."""
from .core import (Candidate, allocate, build_adjacency, empirical_capacities,
                   land_capacities, rank_candidates, required_capacity,
                   evaluate_allocation, greedy_dispatch, static_requirement,
                   match_static_capacity, simulate, theoretical_capacities, microgrid_centers,
                   fence_occupancy_metrics, spatial_coverage, inventory_after_turnover, apply_dispatch)

__all__ = ["Candidate", "allocate", "build_adjacency", "empirical_capacities",
           "land_capacities", "rank_candidates", "required_capacity",
           "evaluate_allocation", "greedy_dispatch", "static_requirement",
           "match_static_capacity", "simulate", "theoretical_capacities", "microgrid_centers",
           "fence_occupancy_metrics", "spatial_coverage", "inventory_after_turnover", "apply_dispatch"]

