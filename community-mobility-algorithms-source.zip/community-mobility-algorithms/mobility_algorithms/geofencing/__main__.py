import argparse
from .._io import read_json, write_json
from . import simulate


def main():
    parser = argparse.ArgumentParser(description="Independent fence allocation and hourly replay")
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    write_json(args.output, simulate(**read_json(args.input)))


if __name__ == "__main__":
    main()
