"""Priority allocation with unique micro-fence ownership per time step.

    Coordinates, if used, are abstract or projected metre coordinates.
    Candidate eligibility and capacity are explicit caller inputs.
"""
from dataclasses import dataclass, replace
import numpy as np
from .._validation import nonnegative, positive_integer


@dataclass(frozen=True)
class Candidate:
    fence_id: str
    grid_id: int
    capacity: int
    origin_activity: float = 0.0
    destination_activity: float = 0.0
    priority: float = 0.0


def _candidates(candidates, n_grids):
    candidates = [Candidate(**c) if isinstance(c, dict) else c for c in candidates]
    ids = set()
    for c in candidates:
        if not isinstance(c.fence_id, str) or not c.fence_id or c.fence_id in ids:
            raise ValueError("fence_id must be a unique nonempty string")
        ids.add(c.fence_id)
        if not isinstance(c.grid_id, (int, np.integer)) or isinstance(c.grid_id, bool) or not 0 <= c.grid_id < n_grids:
            raise ValueError("Candidate grid_id is out of bounds or noninteger")
        positive_integer(c.capacity, "capacity")
        nonnegative([c.origin_activity, c.destination_activity, c.priority], "candidate scores")
    return candidates


def empirical_capacities(train_occupancy, quantile=0.95):
    """Ceil of training occupancy quantile, minimum one; an empirical proxy."""
    values = nonnegative(train_occupancy, "train_occupancy", 2)
    if not 0 <= quantile <= 1:
        raise ValueError("quantile must be in [0, 1]")
    return np.maximum(1, np.ceil(np.quantile(values, quantile, axis=0))).astype(int)


def land_capacities(usable_area_m2, area_per_bicycle_m2=2.0):
    """Floor of eligible area / area per bike; suitability must be checked upstream."""
    areas = nonnegative(usable_area_m2, "usable_area_m2", 1)
    if not np.isfinite(area_per_bicycle_m2) or area_per_bicycle_m2 <= 0:
        raise ValueError("area_per_bicycle_m2 must be positive")
    raw = areas / area_per_bicycle_m2
    # Remove floating-point roundoff near an exact whole-bicycle boundary.
    stable = np.where(np.isclose(raw, np.rint(raw), rtol=1e-12, atol=1e-12), np.rint(raw), raw)
    return np.floor(stable).astype(int)


def theoretical_capacities(total_area_m2, unsuitable_fraction, area_per_bicycle_m2=2.0):
    """Equation (22), unrounded: area * (1 - unsuitable fraction) / 2 m2."""
    area = nonnegative(total_area_m2, "total_area_m2", 1)
    unsuitable = nonnegative(unsuitable_fraction, "unsuitable_fraction", 1)
    if unsuitable.shape != area.shape or (unsuitable > 1).any():
        raise ValueError("unsuitable_fraction must align with areas and lie in [0, 1]")
    if not np.isfinite(area_per_bicycle_m2) or area_per_bicycle_m2 <= 0:
        raise ValueError("area_per_bicycle_m2 must be positive")
    return area * (1-unsuitable) / area_per_bicycle_m2


def microgrid_centers(centers_m, grid_size_m=500.0, micro_size_m=50.0):
    """Return N x 100 x 2 candidate centers for the nominal 500/50 m setting."""
    centers = _centers(centers_m)
    if not np.isfinite([grid_size_m, micro_size_m]).all() or min(grid_size_m, micro_size_m) <= 0:
        raise ValueError("Grid sizes must be finite and positive")
    n = int(round(grid_size_m/micro_size_m))
    if n < 1 or not np.isclose(n*micro_size_m, grid_size_m):
        raise ValueError("grid_size_m must be an integer multiple of micro_size_m")
    offsets = np.asarray([[-grid_size_m/2+(x+.5)*micro_size_m,
                           -grid_size_m/2+(y+.5)*micro_size_m] for y in range(n) for x in range(n)])
    return centers[:, None, :] + offsets[None, :, :]


def rank_candidates(candidates, n_grids, origin_weight=0.5, destination_weight=0.5):
    positive_integer(n_grids, "n_grids")
    candidates = _candidates(candidates, n_grids)
    weights = nonnegative([origin_weight, destination_weight], "priority weights")
    if weights.sum() <= 0:
        raise ValueError("At least one priority weight must be positive")
    weights /= weights.sum()
    maxima = {}
    for c in candidates:
        old = maxima.get(c.grid_id, (0.0, 0.0))
        maxima[c.grid_id] = (max(old[0], c.origin_activity), max(old[1], c.destination_activity))
    result = []
    for c in candidates:
        origins, destinations = maxima[c.grid_id]
        score = weights[0] * c.origin_activity / (origins or 1.0) + weights[1] * c.destination_activity / (destinations or 1.0)
        result.append(replace(c, priority=float(score)))
    return result


def _centers(centers_m, n=None):
    centers = np.asarray(centers_m, dtype=float)
    if centers.size == 0:
        centers = np.empty((0, 2))
    if centers.ndim != 2 or centers.shape[1] != 2 or not np.isfinite(centers).all():
        raise ValueError("centers_m must be a finite N x 2 array")
    if n is not None and len(centers) != n:
        raise ValueError("centers must align with the grid axis")
    return centers


def build_adjacency(centers_m, radius_m):
    centers = _centers(centers_m)
    if not np.isfinite(radius_m) or radius_m < 0:
        raise ValueError("radius_m must be nonnegative")
    result = {}
    for i, center in enumerate(centers):
        distances = np.linalg.norm(centers - center, axis=1)
        result[i] = sorted((j for j in range(len(centers)) if j != i and distances[j] <= radius_m),
                           key=lambda j: (distances[j], j))
    return result


def required_capacity(inventory, predicted_arrivals, predicted_departures=None):
    stock = nonnegative(inventory, "inventory")
    arrivals = nonnegative(predicted_arrivals, "predicted_arrivals")
    if stock.shape != arrivals.shape:
        raise ValueError("inventory and arrivals must have identical shapes")
    departures = np.zeros_like(stock) if predicted_departures is None else nonnegative(predicted_departures, "predicted_departures")
    if departures.shape != stock.shape:
        raise ValueError("departures must match inventory")
    return np.maximum(stock + arrivals - departures, 0)


def static_requirement(train_inventory, train_arrivals, quantile=0.95):
    inventory = nonnegative(train_inventory, "train_inventory", 2)
    if not 0 <= quantile <= 1:
        raise ValueError("quantile must be in [0, 1]")
    pressure = required_capacity(inventory, train_arrivals)
    return np.quantile(pressure, quantile, axis=0)


def allocate(required, candidates, adjacency=None):
    """Greedy activation: highest demand first, local then neighboring grids.

    No realized arrivals enter this decision. Each micro-fence can serve only
    one target in a time step. Capacity is indivisible and may exceed demand.
    """
    required = nonnegative(required, "required", 1)
    n = len(required)
    candidates = _candidates(candidates, n)
    adjacency = {} if adjacency is None else adjacency
    checked = {}
    for target, neighbors in adjacency.items():
        if not isinstance(target, (int, np.integer)) or not 0 <= target < n:
            raise ValueError("Invalid adjacency target")
        values = list(neighbors)
        if any(not isinstance(j, (int, np.integer)) or not 0 <= j < n or j == target for j in values):
            raise ValueError("Invalid adjacency source")
        if len(set(values)) != len(values):
            raise ValueError("Adjacency sources must be unique")
        checked[target] = values
    by_grid = {g: sorted((c for c in candidates if c.grid_id == g),
                        key=lambda c: (-c.priority, -c.capacity, c.fence_id)) for g in range(n)}
    capacity, local, adjacent = np.zeros(n), np.zeros(n), np.zeros(n)
    reserved, assignments = set(), []
    for target in sorted(range(n), key=lambda g: (-required[g], g)):
        need = int(np.ceil(required[target]))
        for source in [target, *checked.get(target, [])]:
            for candidate in by_grid[source]:
                if capacity[target] >= need:
                    break
                if candidate.fence_id in reserved:
                    continue
                reserved.add(candidate.fence_id)
                capacity[target] += candidate.capacity
                (local if source == target else adjacent)[target] += candidate.capacity
                assignments.append({"target_grid_id": target, "source_grid_id": source,
                                    "fence_id": candidate.fence_id, "capacity": candidate.capacity,
                                    "priority": candidate.priority, "adjacent_expansion": source != target})
            if capacity[target] >= need:
                break
    return {"assignments": assignments, "capacity": capacity,
            "local_capacity": local, "adjacent_capacity": adjacent,
            "unmet_requirement": np.maximum(required-capacity, 0)}


def evaluate_allocation(allocation, actual_pressure):
    """Evaluate AFTER the decision; actual pressure never changes allocation."""
    pressure = nonnegative(actual_pressure, "actual_pressure", 1)
    capacity = nonnegative(allocation["capacity"], "capacity", 1)
    if pressure.shape != capacity.shape:
        raise ValueError("Pressure and capacity must align")
    overflow = np.maximum(pressure-capacity, 0)
    return {"overflow": overflow, "accommodated": pressure-overflow,
            "spare": np.maximum(capacity-pressure, 0),
            "accommodation_rate": float(1-overflow.sum()/pressure.sum()) if pressure.sum() else 1.0,
            "capacity_utilization": float((pressure-overflow).sum()/capacity.sum()) if capacity.sum() else 0.0}


def fence_occupancy_metrics(allocation, observed_occupancy):
    """Equation (28) and Table 2 use DISTINCT occupancy measures.

    Supply measured counts at active fence IDs, not inferred grid pressure.
    Missing active fence observations raise, rather than silently becoming zero.
    """
    rows = []
    for assigned in allocation["assignments"]:
        key = assigned["fence_id"]
        if key not in observed_occupancy:
            raise ValueError("Observed occupancy must cover every active fence")
        occupied = float(nonnegative([observed_occupancy[key]], "fence occupancy")[0])
        rows.append({"fence_id": key, "occupancy_rate": occupied/assigned["capacity"],
                     "occupied_bicycles": occupied, "closed_to_returns": occupied >= assigned["capacity"]})
    share = float(np.mean([row["occupied_bicycles"] > 0 for row in rows])) if rows else None
    return {"fences": rows, "occupied_fence_share": share,
            "empty_fence_share": 1-share if share is not None else None}


def spatial_coverage(parking_points_m, active_fence_centers_m, radius_m=100.0):
    """Section 5.3 spatial coverage only; capacity accommodation is separate."""
    points = _centers(parking_points_m)
    fences = _centers(active_fence_centers_m)
    if not np.isfinite(radius_m) or radius_m < 0:
        raise ValueError("radius_m must be nonnegative")
    covered = np.zeros(len(points), dtype=bool)
    for center in fences:
        covered |= np.linalg.norm(points-center, axis=1) <= radius_m
    return {"covered": covered, "coverage_rate": float(covered.mean()) if len(points) else None,
            "radius_m": float(radius_m)}


def greedy_dispatch(overflow, spare, centers_m, movable=None):
    """Nearest-target greedy redistribution; not a min-cost flow optimum.

    Distance uses grid centers and does not estimate road-network travel.
    Volumes may be fractional when the caller supplies expected demand.
    """
    overflow = nonnegative(overflow, "overflow", 1)
    spare = nonnegative(spare, "spare", 1).copy()
    if spare.shape != overflow.shape:
        raise ValueError("Overflow and spare must align")
    centers = _centers(centers_m, len(overflow))
    moves, bike_m = [], 0.0
    residual = overflow.copy()
    movable = overflow.copy() if movable is None else nonnegative(movable, "movable", 1).copy()
    if movable.shape != overflow.shape:
        raise ValueError("movable must align with overflow")
    for source in np.flatnonzero(overflow > 0):
        targets = sorted((j for j in np.flatnonzero(spare > 0) if j != source),
                         key=lambda j: (np.linalg.norm(centers[source]-centers[j]), j))
        for target in targets:
            moved = min(residual[source], spare[target], movable[source])
            if moved <= 0:
                continue
            distance = float(np.linalg.norm(centers[source]-centers[target]))
            residual[source] -= moved
            movable[source] -= moved
            spare[target] -= moved
            bike_m += moved*distance
            moves.append({"source_grid_id": int(source), "target_grid_id": int(target),
                          "bicycles": float(moved), "distance_m": distance})
    return {"moves": moves, "relocated_bicycles": float(overflow.sum()-residual.sum()),
            "bike_km": bike_m/1000, "remaining_overflow": residual, "remaining_spare": spare}


def match_static_capacity(static_required, target_capacity, candidates):
    """Fixed local control expanded towards an explicit integer capacity budget.

    Retains baseline fences, then expands the grid with the smallest capacity
    ratio. Discrete fence sizes may leave a gap; exact matching is not promised.
    """
    required = nonnegative(static_required, "static_required", 1)
    positive_integer(target_capacity, "target_capacity")
    candidates = _candidates(candidates, len(required))
    baseline = allocate(required, candidates)
    current = baseline["capacity"].copy()
    if target_capacity < current.sum():
        raise ValueError("target_capacity cannot be below baseline capacity")
    used = {a["fence_id"] for a in baseline["assignments"]}
    queues = {g: sorted((c for c in candidates if c.grid_id == g and c.fence_id not in used),
                        key=lambda c: (-c.priority, -c.capacity, c.fence_id)) for g in range(len(required))}
    while current.sum() < target_capacity:
        choices = []
        for grid, queue in queues.items():
            if not queue or baseline["capacity"][grid] <= 0:
                continue
            candidate = queue[0]
            if candidate.capacity <= target_capacity-current.sum():
                ratio = (current[grid]+candidate.capacity)/baseline["capacity"][grid]
                choices.append((ratio, -required[grid], -candidate.priority, grid))
        if not choices:
            break
        grid = min(choices)[-1]
        current[grid] += queues[grid].pop(0).capacity
    return {"required": current, "target_capacity": target_capacity,
            "matched_capacity": int(current.sum()), "capacity_gap": int(target_capacity-current.sum())}


def inventory_after_turnover(inventory, arrivals, hour_of_day, night_hours=(0, 1, 2, 3, 4, 5)):
    """Night [00:00,06:00): stock accumulates. Day [06:00,24:00): old stock clears."""
    stock = nonnegative(inventory, "inventory", 1)
    arrivals = nonnegative(arrivals, "arrivals", 1)
    if stock.shape != arrivals.shape:
        raise ValueError("Inventory and arrivals must align")
    if not isinstance(hour_of_day, (int, np.integer)) or not 0 <= hour_of_day < 24:
        raise ValueError("hour_of_day must be an integer in [0, 23]")
    if any(not isinstance(hour, (int, np.integer)) or not 0 <= hour < 24 for hour in night_hours):
        raise ValueError("night_hours must contain integers in [0, 23]")
    return stock+arrivals if hour_of_day in night_hours else arrivals.copy()


def apply_dispatch(inventory, moves):
    """Conserve total inventory; infeasible transfers raise instead of clipping."""
    updated = nonnegative(inventory, "inventory", 1).copy()
    for move in moves:
        source, target, count = move["source_grid_id"], move["target_grid_id"], move["bicycles"]
        if (not isinstance(source, (int, np.integer)) or not isinstance(target, (int, np.integer))
                or not 0 <= source < len(updated) or not 0 <= target < len(updated)):
            raise ValueError("Transfer index out of range")
        count = float(nonnegative([count], "transfer count")[0])
        if count > updated[source]+1e-9:
            raise ValueError("Transfer exceeds retained source inventory")
        updated[source] -= count
        updated[target] += count
    return updated


def simulate(initial_inventory, predicted_arrivals, actual_arrivals, candidates, centers_m,
             static_required=None, adjacency=None, radius_m=None, cost_per_bike_km=4.1,
             start_hour=0, night_hours=(0, 1, 2, 3, 4, 5),
             observed_fence_occupancy=None, include_matched_static=False,
             turnover_dispatch_order=None):
    """Hourly simulation with feedback, fixed static layouts and common capacities.

    The paper leaves the within-hour order of turnover and relocation unspecified.
    This implementation requires explicit acknowledgement of 'turnover_then_dispatch':
    evaluate B+A pressure, clear daytime carried stock, dispatch retained inventory,
    and carry the resulting inventory into the following hour. Limiting transfer
    volume to retained inventory prevents negative stocks or invented bicycles.
    """
    if turnover_dispatch_order != "turnover_then_dispatch":
        raise ValueError("Explicitly select turnover_dispatch_order='turnover_then_dispatch'; "
                         "within-hour ordering is not specified in the manuscript")
    initial = nonnegative(initial_inventory, "initial_inventory", 1)
    predicted = nonnegative(predicted_arrivals, "predicted_arrivals", 2)
    actual = nonnegative(actual_arrivals, "actual_arrivals", 2)
    if predicted.shape != actual.shape or predicted.shape[1] != len(initial):
        raise ValueError("Forecasts, actual arrivals and initial inventory must align")
    n, hours = len(initial), len(actual)
    centers = _centers(centers_m, n)
    cost = float(nonnegative([cost_per_bike_km], "cost_per_bike_km")[0])
    if not isinstance(start_hour, int) or not 0 <= start_hour < 24:
        raise ValueError("start_hour must be an integer in [0, 23]")
    if adjacency is None and radius_m is None:
        raise ValueError("Supply adjacency or radius_m explicitly; no adjacency cutoff is stated in the manuscript")
    if adjacency is not None and radius_m is not None:
        raise ValueError("Supply adjacency or radius_m, not both")
    if adjacency is None:
        adjacency = build_adjacency(centers, radius_m)
    elif isinstance(adjacency, dict):
        # JSON object keys are strings; values remain integer grid indices.
        adjacency = {int(key): value for key, value in adjacency.items()}
    candidates = rank_candidates(candidates, n)
    if observed_fence_occupancy is not None and len(observed_fence_occupancy) != hours:
        raise ValueError("Provide one observed-fence occupancy mapping per hour")
    rows, summaries = [], []

    def run_strategy(name, fixed=None):
        inventory = initial.copy()
        prior_active = None
        local_rows = []
        for t in range(hours):
            required = required_capacity(inventory, predicted[t])
            pressure = required_capacity(inventory, actual[t])
            allocation = allocate(required, candidates, adjacency) if fixed is None else fixed
            evaluation = evaluate_allocation(allocation, pressure)
            retained = inventory_after_turnover(inventory, actual[t], (start_hour+t) % 24, night_hours)
            dispatch = greedy_dispatch(evaluation["overflow"], evaluation["spare"], centers, movable=retained)
            following = apply_dispatch(retained, dispatch["moves"])
            active = {item["fence_id"] for item in allocation["assignments"]}
            occupancy = (fence_occupancy_metrics(allocation, observed_fence_occupancy[t])
                         if observed_fence_occupancy is not None else None)
            local_rows.append({"strategy": name, "time_index": t, "hour_of_day": (start_hour+t) % 24,
                               "start_inventory": inventory.copy(), "next_inventory": following.copy(),
                               "actual_pressure": pressure, "allocation": allocation, "evaluation": evaluation,
                               "dispatch": dispatch, "dispatch_cost_CNY": dispatch["bike_km"]*cost,
                               "fence_occupancy": occupancy,
                               "activations_after_setup": len(active-prior_active) if prior_active is not None else 0,
                               "deactivations_after_setup": len(prior_active-active) if prior_active is not None else 0})
            prior_active, inventory = active, following
        total_pressure = float(sum(row["actual_pressure"].sum() for row in local_rows))
        unmet = float(sum(row["evaluation"]["overflow"].sum() for row in local_rows))
        transfers = float(sum(row["dispatch"]["relocated_bicycles"] for row in local_rows))
        total_cost = float(sum(row["dispatch_cost_CNY"] for row in local_rows))
        occupied = [row["fence_occupancy"]["occupied_fence_share"] for row in local_rows
                    if row["fence_occupancy"] is not None and row["fence_occupancy"]["occupied_fence_share"] is not None]
        summaries.append({"strategy": name, "cumulative_hourly_pressure": total_pressure,
                          "accommodation_rate": 1-unmet/total_pressure if total_pressure else 1.0,
                          "cumulative_unmet_pressure": unmet,
                          "overflow_grid_hours": int(sum((row["evaluation"]["overflow"] > 0).sum() for row in local_rows)),
                          "mean_active_fences": float(np.mean([len(row["allocation"]["assignments"]) for row in local_rows])),
                          "mean_activated_capacity": float(np.mean([row["allocation"]["capacity"].sum() for row in local_rows])),
                          "mean_occupied_fence_share": float(np.mean(occupied)) if occupied else None,
                          "mean_empty_fence_share": 1-float(np.mean(occupied)) if occupied else None,
                          "simulated_bicycle_transfers": transfers,
                          "dispatch_bike_km": float(sum(row["dispatch"]["bike_km"] for row in local_rows)),
                          "dispatch_cost_CNY": total_cost,
                          "cost_per_transfer_CNY": total_cost/transfers if transfers else None,
                          "activations_after_setup": sum(row["activations_after_setup"] for row in local_rows),
                          "deactivations_after_setup": sum(row["deactivations_after_setup"] for row in local_rows)})
        rows.extend(local_rows)
        return local_rows

    dynamic = run_strategy("dynamic")
    matching = None
    if static_required is not None:
        static = nonnegative(static_required, "static_required", 1)
        if static.shape != (n,):
            raise ValueError("static_required must have N elements")
        # Historical and matched static layouts are selected locally once.
        run_strategy("historical_static", allocate(static, candidates))
        if include_matched_static:
            mean_capacity = float(np.mean([row["allocation"]["capacity"].sum() for row in dynamic]))
            baseline_capacity = allocate(static, candidates)["capacity"].sum()
            if mean_capacity < baseline_capacity or mean_capacity < 1:
                raise ValueError("Expansion-based matching requires dynamic mean capacity >= historical baseline")
            target = int(np.floor(mean_capacity))
            matching = match_static_capacity(static, target, candidates)
            matching["dynamic_mean_capacity"] = mean_capacity
            matching["gap_from_dynamic_mean"] = mean_capacity-matching["matched_capacity"]
            run_strategy("matched_static", allocate(matching["required"], candidates))
    elif include_matched_static:
        raise ValueError("include_matched_static requires training-derived static_required")
    dynamic_cost = summaries[0]["dispatch_cost_CNY"]
    for summary in summaries[1:]:
        baseline_cost = summary["dispatch_cost_CNY"]
        summary["dynamic_cost_reduction_pct"] = 100*(baseline_cost-dynamic_cost)/baseline_cost if baseline_cost else None
    return {"hourly": rows, "summary": summaries, "capacity_matching": matching,
            "night_hours": list(night_hours), "turnover_dispatch_order": turnover_dispatch_order,
            "occupancy_source": "provided per-fence observations" if observed_fence_occupancy is not None else "unavailable",
            "capacity_assumption": "externally screened land-use capacities; empirical proxies are not the paper experiment"}
