"""Build a source-only ZIP from an explicit file allowlist (never directory globbing).

This utility has no network access and never adds files to Git. It also refuses
symlinks, suspicious credential/path text, and unexpected unignored source files.
The checks are a publication guard, not an anonymization mechanism.
"""
import argparse
import hashlib
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FILES = (
    ".gitignore", ".github/workflows/tests.yml", "LICENSE", "README.md", "README.en.md",
    "pyproject.toml", "docs/ALGORITHMS.md", "docs/PRIVACY.md",
    "examples/__init__.py", "examples/synthetic_demo.py",
    "mobility_algorithms/__init__.py", "mobility_algorithms/_validation.py", "mobility_algorithms/_io.py",
    "mobility_algorithms/community/__init__.py", "mobility_algorithms/community/__main__.py",
    "mobility_algorithms/community/core.py",
    "mobility_algorithms/prediction/__init__.py", "mobility_algorithms/prediction/__main__.py",
    "mobility_algorithms/prediction/features.py", "mobility_algorithms/prediction/metrics.py",
    "mobility_algorithms/prediction/models.py", "mobility_algorithms/prediction/training.py",
    "mobility_algorithms/prediction/arima.py", "mobility_algorithms/prediction/pipeline.py",
    "mobility_algorithms/geofencing/__init__.py", "mobility_algorithms/geofencing/__main__.py",
    "mobility_algorithms/geofencing/core.py", "tests/test_algorithms.py", "tests/test_manuscript.py", "scripts/build_release.py",
)
IGNORED_PARTS = {".git", ".venv", "venv", "__pycache__", ".pytest_cache", "dist", "build",
                 "data", "private", "outputs", "results", "checkpoints", ".idea", ".vscode"}
# Patterns are assembled so the scanner itself does not contain matching secrets.
PATTERNS = {
    "private user path": re.compile(r"[A-Za-z]:[\\/]+Users[\\/]|/" + r"home/[^/\s]+/|/" + r"Users/[^/\s]+/", re.I),
    "GitHub credential": re.compile(r"(?:gh[pousr]_)[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{30,}"),
    "API credential": re.compile(r"sk-[A-Za-z0-9_-]{24,}|AKIA[A-Z0-9]{16}"),
    "private key": re.compile(r"-----BEGIN " + r"(?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "assigned secret": re.compile(r'''(?i)(?:api_key|password|access_token|secret_key)\s*[:=]\s*["'][^"']{8,}["']'''),
}


def approved_files(root=ROOT):
    root = root.resolve()
    payload = {}
    for relative in FILES:
        path = root / relative
        if path.is_symlink() or root not in path.resolve().parents:
            raise ValueError(f"Unsafe path: {relative}")
        # Parent symlinks are rejected even when they happen to point inside root.
        if any(p.is_symlink() for p in path.parents if p != root and root in p.parents):
            raise ValueError(f"Symlink parent: {relative}")
        raw = path.read_bytes()
        if len(raw) > 250_000:
            raise ValueError(f"Unexpectedly large source file: {relative}")
        content = raw.decode("utf-8")
        for kind, pattern in PATTERNS.items():
            if pattern.search(content):
                raise ValueError(f"Publication check failed ({kind}): {relative}")
        payload[relative] = raw
    # Ignore known runtime directories; they are never part of the ZIP.
    for path in root.rglob("*"):
        relative = path.relative_to(root)
        if any(part in IGNORED_PARTS or part.endswith(".egg-info") for part in relative.parts):
            continue
        if relative.as_posix() == "SHA256SUMS.txt":
            expected = checksum_manifest(payload)
            if path.is_symlink() or path.read_text(encoding="utf-8") != expected:
                raise ValueError("Checksum manifest does not match source files; regenerate the release snapshot")
            continue
        if path.is_file() and relative.as_posix() not in FILES:
            raise ValueError(f"Unreviewed file in release tree: {relative.as_posix()}")
    return payload


def checksum_manifest(payload):
    return "\n".join(f"{hashlib.sha256(raw).hexdigest()}  {name}" for name, raw in sorted(payload.items()))+"\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="Validate without writing an archive")
    parser.add_argument("--output", default="dist/community-mobility-algorithms-source.zip")
    args = parser.parse_args()
    payload = approved_files()
    if args.check:
        print(f"PASS: {len(payload)} allowlisted source/documentation files; no data included")
        return
    output = Path(args.output)
    if not output.is_absolute():
        output = ROOT/output
    output.parent.mkdir(parents=True, exist_ok=True)
    # A checksum list is created from exactly the in-memory bytes being zipped.
    checksums = checksum_manifest(payload)
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for relative, raw in sorted(payload.items()):
            archive.writestr("community-mobility-algorithms/"+relative, raw)
        archive.writestr("community-mobility-algorithms/SHA256SUMS.txt", checksums)
    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    print(f"Created {output.name}: {len(payload)} source files + checksum manifest")
    print(f"SHA256 {digest}")


if __name__ == "__main__":
    main()
